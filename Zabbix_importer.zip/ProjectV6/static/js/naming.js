/* Global helpers, naming, tags, macros */
window.$=id=>document.getElementById(id);
window.escapeHtml=str=>str==null?'':String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
window.defaultPorts={'1':'10050','2':'161','3':'623','4':'12345'};
window.state={rows:[],metadata:{groups:[],templates:[],proxies:[]},importing:false,selectedGroups:new Set(),selectedTemplates:new Set()};
/* Naming convention builder and live preview. */
const namingFieldIds=['f1_tcode','f2_rcode','f3_zcode','f4_scode','f5_name','f6_web'];
window.buildNamingPrefix=function(){return namingFieldIds.map(id=>String($(id)?.value||'').trim()).filter(Boolean).join(' - ')};
window.finalHost=function(base=''){
  const prefix=window.buildNamingPrefix();
  const hostname=String(base??'').trim();
  return [prefix,hostname].filter(Boolean).join(' - ');
};
window.updateNamingPreview=function(){
  const preview=$('namingPreview')||$('singleLivePreview');
  if(!preview)return;
  const base=String($('singleBaseHost')?.value||'').trim();
  preview.textContent=window.finalHost(base)||'(Enter a base hostname)';
};
// Keep the existing controller/API name while routing all preview updates cleanly.
window.updateSinglePreview=window.updateNamingPreview;
document.addEventListener('input',e=>{
  if(namingFieldIds.includes(e.target?.id)||e.target?.id==='singleBaseHost')window.updateNamingPreview();
});
document.addEventListener('change',e=>{
  if(namingFieldIds.includes(e.target?.id)||e.target?.id==='singleBaseHost')window.updateNamingPreview();
});
/* Default tag set rendered for every host (Z-HStatus is locked to InProgress). */
const DEFAULT_TAGS=[
  {key:'Z-Admin',value:''},
  {key:'Z-HStatus',value:'InProgress',locked:true},
  {key:'Z-Owner',value:''},
  {key:'Z-Role',value:''},
  {key:'Z-Type',value:''},
  {key:'Z-Zone',value:''},
  {key:'Z-Ticket',value:''}
];
window.DEFAULT_TAGS=DEFAULT_TAGS;
const FIXED_TAG={tag:'Z-HStatus',value:'InProgress'};
window.FIXED_STATUS_TAG=FIXED_TAG;
window.addTagPair=function(tag='',val='',locked=false,containerId='tagsList'){
  const list=$(containerId);
  if(!list)return;
  const row=document.createElement('div');
  row.className='grid2 tag-row';
  row.style.marginBottom='6px';
  if(locked)row.dataset.locked='1';
  const ro=locked?'readonly':'';
  row.innerHTML=`<input type="text" class="input tag-name" placeholder="Tag Name" value="${escapeHtml(tag)}" ${ro}><div style="display:flex;gap:6px"><input type="text" class="input tag-value" placeholder="Value" value="${escapeHtml(val)}" style="flex:1" ${ro}><button type="button" class="btn danger small tag-del-btn" ${locked?'disabled style="display:none"':'style="display:\'\''}">×</button></div>`;
  const btn=row.querySelector('.tag-del-btn');
  if(locked){btn.disabled=true;btn.style.display='none'}
  else btn.onclick=()=>row.remove();
  list.appendChild(row);
  return row;
};
window.getTagPairs=function(containerId='tagsList'){
  return Array.from($(containerId)?.querySelectorAll('.tag-row')||[]).map(r=>({
    tag:r.querySelector('.tag-name').value.trim(),
    value:r.querySelector('.tag-value').value.trim(),
    locked:r.dataset.locked==='1'
  })).filter(x=>x.tag && (x.tag === FIXED_TAG.tag || x.value));
};
window.getTags=function(containerId='tagsList'){
  const tags=window.getTagPairs(containerId).map(({tag,value})=>({tag,value}));
  /* Z-HStatus: InProgress is mandatory — add or enforce it. */
  const i=tags.findIndex(x=>x.tag===FIXED_TAG.tag);
  if(i<0)tags.push({...FIXED_TAG});
  else tags[i].value=FIXED_TAG.value;
  return tags;
};
window.initDefaultTags=function(containerId='tagsList'){
  const list=$(containerId);
  if(!list)return;
  list.innerHTML='';
  DEFAULT_TAGS.forEach(t=>window.addTagPair(t.key,t.value,!!t.locked,containerId));
};
function addMacroRow(macro='',value='',desc='',type=0){const list=$('macrosList');if(!list)return;const row=document.createElement('div');row.className='grid3 macro-row';row.style.marginBottom='6px';row.innerHTML=`<input type="text" class="input macro-name" placeholder="{$MACRO}" value="${escapeHtml(macro)}"><input type="text" class="input macro-val" placeholder="Value" value="${escapeHtml(value)}"><div style="display:flex;gap:6px"><select class="macro-type" title="Macro value type"><option value="0" ${String(type)==='1'?'':'selected'}>Text</option><option value="1" ${String(type)==='1'?'selected':''}>Secret</option></select><input type="text" class="input macro-desc" placeholder="Description" value="${escapeHtml(desc)}" style="flex:1"><button type="button" class="btn danger small macro-del-btn">×</button></div>`;row.querySelector('.macro-del-btn').onclick=()=>row.remove();list.appendChild(row)}
window.addMacroRow=window.addMacroRow||addMacroRow;
function getHostMacros(){return Array.from(document.querySelectorAll('#macrosList .macro-row')).map(r=>{const x={macro:r.querySelector('.macro-name').value.trim(),value:r.querySelector('.macro-val').value.trim(),type:parseInt(r.querySelector('.macro-type')?.value||'0',10)||0},d=r.querySelector('.macro-desc').value.trim();if(d)x.description=d;return x}).filter(x=>x.macro)}
window.getHostMacros=getHostMacros;
