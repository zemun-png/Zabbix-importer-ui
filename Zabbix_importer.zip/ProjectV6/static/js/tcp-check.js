/* TCP Check host browser and macro editor (IP-block layout). Kept isolated from the other tabs. */
(function () {
  const T_ACTIVE = 'Z-TCP Connection Check - Zabbix Agent-Active';
  const T_ACTIVE_INEXT = 'Z-TCP Connection Check - Zabbix Agent-Active-INEXT';
  const T_AGENT = 'Z-TCP Connection Check - Zabbix Agent';
  const T_AGENT_INEXT = 'Z-TCP Connection Check - Zabbix Agent-INEXT';
  const T1=T_ACTIVE, T2=T_ACTIVE_INEXT;
  function templateBadge(t){return t&&String(t).includes('INEXT')?'<span class="badge badge-warning">INEXT</span>':'<span class="badge badge-info">Agent</span>'; }
  function detectHostMode(host) {
    if (!host) return 'both';
    const tmpls = (host.tcp_templates || host.templates || []).map(t => typeof t === 'string' ? t : (t.name || ''));
    const hasInextTmpl = tmpls.some(t => t.includes('INEXT'));
    const hasAgentTmpl = tmpls.some(t => !t.includes('INEXT') && (t.includes('Agent-Active') || t.includes('Zabbix Agent')));
    const macros = host.macros || {};
    const hasInextMacros = Boolean((macros['{$DST_IP_INTERNAL}'] || macros['{$DST_PORT_INTERNAL}'] || macros['{$DST_IP_EXTERNAL}'] || macros['{$DST_PORT_EXTERNAL}']));
    const hasAgentMacros = Boolean((macros['{$DST_IP}'] || macros['{$DST_PORT}']));
    if (hasInextTmpl || (hasInextMacros && !hasAgentMacros && !hasAgentTmpl)) return 'inext';
    if (hasAgentTmpl || (hasAgentMacros && !hasInextMacros && !hasInextTmpl)) return 'agent';
    if (hasInextMacros && hasAgentMacros) return 'both';
    return hasInextTmpl ? 'inext' : (hasAgentTmpl ? 'agent' : 'both');
  }
  const state={hosts:[],selected:null,details:null,wired:false};
  const $=id=>document.getElementById(id);
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function msg(text,kind){const el=$('tcpMessage');if(el){el.textContent=text||'';el.className='msg'+(text?' '+(kind||''):'');}}
  async function post(url,body){return window.api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});}
  function templates(h){return Array.isArray(h.tcp_templates)?h.tcp_templates:[];}
  function interfaceAddresses(h){return (h.interfaces||[]).flatMap(i=>[i.ip,i.dns]).filter(Boolean);}

  /* ---------- normalization ---------- */
  const ZERO_WIDTH=/[\u200B-\u200D\u2060\uFEFF\u180E\u00AD]/g;
  function normalizeText(v){
    let s=String(v==null?'':v).replace(ZERO_WIDTH,'');
    return s.replace(/[\u06F0-\u06F9]/g,d=>String(d.charCodeAt(0)-0x06F0))
            .replace(/[\u0660-\u0669]/g,d=>String(d.charCodeAt(0)-0x0660))
            .replace(/[\u0966-\u096F]/g,d=>String(d.charCodeAt(0)-0x0966))
            .replace(/[\u09E6-\u09EF]/g,d=>String(d.charCodeAt(0)-0x09E6));
  }
  function normalizePort(v){return normalizeText(v).replace(/[\u066B\u066C]/g,'').trim().replace(/\s+/g,' ');}
  function normalizeIp(v){return normalizeText(v).trim().replace(/\s+/g,' ');}
  function validPort(p){return /^\d+$/.test(p)&&Number(p)>=1&&Number(p)<=65535;}

  /* ---------- host list (search by host name AND IP) ---------- */
  function renderHosts(){
    const list=$('tcpHostList');if(!list)return;
    const query=normalizeText($('tcpHostSearch')?.value||'').trim().toLowerCase(),filter=$('tcpTemplateFilter')?.value||'';
    const hits=state.hosts.filter(h=>{
      const ts=templates(h);
      const search=[h.host,h.name,...interfaceAddresses(h),...macroTargetIps(h)].some(v=>normalizeText(v).toLowerCase().includes(query));
      return(!filter||ts.includes(filter))&&(!query||search);
    });
    if(!hits.length){list.innerHTML='<div class="picker-empty">No matching TCP hosts (name or IP)</div>';return;}
    list.innerHTML=hits.map(h=>{const ts=templates(h),ips=interfaceAddresses(h).join(' · ');
      return `<button type="button" class="tcp-host-item${String(h.hostid)===String(state.selected)?' active':''}" data-hostid="${esc(h.hostid)}"><span class="tcp-host-name">${esc(h.name||h.host||h.hostid)}</span><span class="tcp-host-tech">${esc(h.host||'')}${ips?`<small class="tcp-host-ips">${esc(ips)}</small>`:''}</span><span class="tcp-badges">${ts.map(t=>`<span class="tcp-template-badge">${templateBadge(t)}</span>`).join('')}</span></button>`;}).join('');
    list.querySelectorAll('[data-hostid]').forEach(b=>b.addEventListener('click',()=>selectHost(b.dataset.hostid)));
  }
  async function loadTcpHosts(){const list=$('tcpHostList');if(list)list.innerHTML='<div class="picker-empty">Loading TCP hosts…</div>';try{const data=await post('/api/tcp_hosts',{});state.hosts=Array.isArray(data.hosts)?data.hosts:[];renderHosts();}catch(e){console.error('[TCP] host list request failed',e);if(list)list.innerHTML=`<div class="tcp-warning">${esc(e.message||e)}</div>`;}}

  /* ---------- macro <-> IP blocks ---------- */
  function listMacro(m){return normalizeText(state.details?.macros?.[m]?.value||'').split(',').map(x=>x.trim()).filter(Boolean);}
  /* All target IPs advertised by the host's macros, for host-list search. */
  function macroTargetIps(h){
    const names=['{$DST_IP}','{$DST_IP_INTERNAL}','{$DST_IP_EXTERNAL}'];
    const out=[];for(const m of names){for(const v of listMacroOn(m,h))if(!out.includes(v))out.push(v);}return out;
  }
  function listMacroOn(m,h){
    const raw=(h&&h.macros&&h.macros[m]&&h.macros[m].value)||(state.details?.macros?.[m]?.value)||'';
    return normalizeText(raw).split(',').map(x=>x.trim()).filter(Boolean);
  }
  /* Group parallel {ip, port} pairs into blocks: [{ip, ports:[...], isNew, isModified}] */
  function blocksFromPairs(pairs){
    const blocks=[],byIp=new Map();
    for(const p of pairs){const ip=normalizeIp(p.ip),port=normalizePort(p.port);let block=ip?byIp.get(ip):null;
      if(!block){block={ip,ports:[],isNew:false,isModified:false};blocks.push(block);if(ip)byIp.set(ip,block);}
      if(port&&!block.ports.includes(port))block.ports.push(port);
    }return blocks;
  }
  function parseBulkTargets(ipsText,portsText){
    const split=v=>normalizeText(v).split(',').map(x=>x.trim()).filter(Boolean);
    const ips=split(ipsText).map(normalizeIp),ports=split(portsText).map(normalizePort),targets=[],errors=[];
    if(!ips.length)errors.push('Enter at least one IP/host.');
    if(!ports.length)errors.push('Enter at least one port.');
    for(const ip of ips){
      const ipOk=!!ip&&!/[\s,]/.test(ip);
      if(!ipOk)errors.push(`Invalid IP/host: ${ip||'(empty)'}.`);
      for(const port of ports){
        const portOk=validPort(port);
        if(!portOk)errors.push(`Invalid port ${port?`(${port})`:''}; use 1 to 65535.`);
        targets.push({ip,port,valid:ipOk&&portOk});
      }
    }
    return {targets,errors};
  }
  function dedupeTargets(targets){
    const blocks=[],byIp=new Map();for(const t of targets||[]){const ip=normalizeIp(t.ip),port=normalizePort(t.port);if(!ip)continue;let b=byIp.get(ip);if(!b){b={ip,ports:[],isNew:true,isModified:false};byIp.set(ip,b);blocks.push(b);}if(port&&validPort(port)&&!b.ports.includes(port))b.ports.push(port);}return blocks;
  }
  function mergeTargetsIntoBlocks(blocks,targets){
    const out=(blocks||[]).map(b=>({ip:normalizeIp(b.ip),ports:[...(b.ports||[])].map(normalizePort),isNew:!!b.isNew,isModified:!!b.isModified}));
    for(const t of targets||[]){if(t.valid===false||!normalizeIp(t.ip)||!validPort(normalizePort(t.port)))continue;const ip=normalizeIp(t.ip);let b=out.find(x=>x.ip===ip);if(!b){b={ip,ports:[],isNew:true,isModified:false};out.push(b);}const port=normalizePort(t.port);if(!b.ports.includes(port))b.ports.push(port);}return out;
  }
  function macroPairs(im,pm){const ips=listMacro(im),ports=listMacro(pm),n=Math.max(ips.length,ports.length);
    return blocksFromPairs(Array.from({length:n},(_,i)=>({ip:ips[i]||'',port:ports[i]||''})));}
  /* Expand blocks back into equal-length parallel arrays (Bash LLD contract). */
  function serializeBlocks(blocks){
    const ips=[],ports=[];
    for(const b of blocks){
      const ip=normalizeIp(b.ip);
      const ps=(b.ports||[]).map(normalizePort).filter(Boolean);
      if(!ip&&!ps.length)continue;
      const use=ps.length?ps:[''];
      for(const p of use){ips.push(ip);ports.push(p);}
    }
    return {ips:ips.join(','),ports:ports.join(','),count:ips.length};
  }

  /* ---------- editor render ---------- */
  const CONF={agent:{ipMacro:'{$DST_IP}',portMacro:'{$DST_PORT}'},
              external:{ipMacro:'{$DST_IP_EXTERNAL}',portMacro:'{$DST_PORT_EXTERNAL}'},
              internal:{ipMacro:'{$DST_IP_INTERNAL}',portMacro:'{$DST_PORT_INTERNAL}'}};
  function keyMacros(key){return key==='agent'?['{$DST_IP}','{$DST_PORT}']:key==='external'?['{$DST_IP_EXTERNAL}','{$DST_PORT_EXTERNAL}']:['{$DST_IP_INTERNAL}','{$DST_PORT_INTERNAL}'];}

  function bulkEntryMarkup(key){return `<div class=\"tcp-bulk-entry\" data-bulk=\"${key}\"><label>Bulk IPs (comma-separated)<input class=\"input tcp-bulk-ips\" placeholder=\"10.0.0.1, 10.0.0.2\"></label><label>Ports (one shared or comma-separated)<input class=\"input tcp-bulk-ports\" placeholder=\"80, 443\"></label><button type=\"button\" class=\"btn small tcp-bulk-add\">Add targets</button><div class=\"tcp-bulk-error\" role=\"alert\" aria-live=\"polite\"></div></div>`;}
  function renderDetails(){
    const h=state.details,box=$('tcpHostDetails'),editor=$('tcpPairEditor');if(!h){if(box)box.innerHTML='Select a host';if(editor)editor.innerHTML='Select a host';return;}
    const interfaces=(h.interfaces||[]).map(i=>`${i.type==='1'?'Agent':i.type==='2'?'SNMP':i.type==='3'?'IPMI':i.type==='4'?'JMX':'Interface'} · ${i.useip==='1'?normalizeIp(i.ip):normalizeIp(i.dns)}:${normalizePort(i.port)}${i.main==='1'?' (main)':''}`).join(' · ')||'None';
    box.innerHTML=`<div class="tcp-summary-line"><strong>${esc(h.name||h.host)}</strong><span>${esc(h.host||'')}</span><span class="tcp-status ${h.status==='0'?'enabled':'disabled'}">${h.status==='0'?'Enabled':'Disabled'}</span></div><div class="tcp-summary-line tcp-summary-sub"><span>Interfaces: ${esc(interfaces)}</span><span>Templates: ${esc((h.tcp_templates||[]).join(' · ')||'None')}</span></div>`;
    const mode = detectHostMode(h);
    const agentBlock=`<section class="tcp-editor" data-section="agent"<div class="tcp-section-heading"><div><h3>${esc(T1)}</h3><p>Each destination IP is one block; add port chips for every port checked on that IP. Saved as parallel comma-separated {$DST_IP} / {$DST_PORT} arrays.</p></div><button type="button" class="btn tcp-add" data-add="agent">＋ Add destination</button></div>${bulkEntryMarkup('agent')}<div class="tcp-block-list" data-editor="agent"></div><div class="tcp-preview" data-preview="agent"></div></section>`;
    const inextBlock=`<section class="tcp-editor" data-section="inext"<div class="tcp-section-heading"><div><h3>${esc(T2)}</h3><p>External and internal destinations use the same IP-block layout with their own macros.</p></div></div><div class="tcp-two-cards"><article class="tcp-pair-card"><div class="tcp-section-heading"><h4>DST Internal</h4><button type="button" class="btn small tcp-add" data-add="internal">＋ Add</button></div>${bulkEntryMarkup('internal')}<div class="tcp-block-list" data-editor="internal"></div><div class="tcp-preview" data-preview="internal"></div></article><article class="tcp-pair-card"><div class="tcp-section-heading"><h4>DST External</h4><button type="button" class="btn small tcp-add" data-add="external">＋ Add</button></div>${bulkEntryMarkup('external')}<div class="tcp-block-list" data-editor="external"></div><div class="tcp-preview" data-preview="external"></div></article></div></section>`;
    /* Always render ALL THREE editor containers in the DOM; toggle visibility via CSS display
       so querySelector('[data-editor=...]') never returns null (fixes "wrap is null" crash). */
    editor.innerHTML=agentBlock+inextBlock;
    const sectionAgent=editor.querySelector('[data-section="agent"]');
    const sectionInext=editor.querySelector('[data-section="inext"]');
    const showAgent=(mode==='agent'||mode==='both'||mode==='unknown');
    const showInext=(mode==='inext'||mode==='both'||mode==='unknown');
    if(sectionAgent)sectionAgent.style.display=showAgent?'block':'none';
    if(sectionInext)sectionInext.style.display=showInext?'block':'none';
    editor.dataset.mode=mode;
    for(const key of Object.keys(CONF)){
      const wrap=editor.querySelector(`[data-editor="${key}"]`);
      if(!wrap)continue; /* safe null-check */
      wrap.dataset.ipMacro=CONF[key].ipMacro;wrap.dataset.portMacro=CONF[key].portMacro;
      const [im,pm]=keyMacros(key);
      macroPairs(im,pm).forEach(b=>addBlock(key,b));
      updatePreview(key);
    }
    editor.querySelectorAll('.tcp-bulk-add').forEach(btn=>btn.addEventListener('click',()=>{
      const form=btn.closest('[data-bulk]'),key=form.dataset.bulk,result=parseBulkTargets(form.querySelector('.tcp-bulk-ips').value,form.querySelector('.tcp-bulk-ports').value);
      const error=form.querySelector('.tcp-bulk-error');error.textContent=result.errors.join(' ');
      const good=result.targets.filter(t=>t.valid);if(!good.length)return;
      mergeIntoEditor(key,good);form.querySelector('.tcp-bulk-ips').value='';form.querySelector('.tcp-bulk-ports').value='';updatePreview(key);
    }));
    editor.querySelectorAll('[data-add]').forEach(b=>b.addEventListener('click',()=>{
      const k=b.dataset.add,blk=addBlock(k,{ip:'',ports:[''],isNew:true,isModified:false});
      updatePreview(k);blk?.querySelector('.tcp-ip-input')?.focus();
    }));
  }

  function mergeIntoEditor(key,targets){
    const wrap=document.querySelector(`[data-editor=\"${key}\"]`);if(!wrap)return;
    const existing=Array.from(wrap.querySelectorAll('.tcp-ip-block')).map(block=>({block,ip:normalizeIp(block.querySelector('.tcp-ip-input').value)}));
    for(const t of targets){let row=existing.find(x=>x.ip===normalizeIp(t.ip));if(!row){const block=addBlock(key,{ip:t.ip,ports:[],isNew:true});row={block,ip:normalizeIp(t.ip)};existing.push(row);}const chips=Array.from(row.block.querySelectorAll('.tcp-port-chip'));const seen=new Set(chips.map(c=>normalizePort(c.querySelector('input').value)).filter(Boolean));if(!seen.has(t.port))addChip(row.block,key,t.port,false);blockStatus(row.block);}
    dedupeDomBlocks(key);
  }
  function dedupeDomBlocks(key){
    const wrap=document.querySelector(`[data-editor=\"${key}\"]`);if(!wrap)return;const byIp=new Map();
    Array.from(wrap.querySelectorAll('.tcp-ip-block')).forEach(block=>{const ip=normalizeIp(block.querySelector('.tcp-ip-input').value);if(!ip)return;const prior=byIp.get(ip);if(!prior){byIp.set(ip,block);return;}
      const seen=new Set(Array.from(prior.querySelectorAll('.tcp-port-chip input')).map(i=>normalizePort(i.value)).filter(Boolean));
      Array.from(block.querySelectorAll('.tcp-port-chip input')).forEach(input=>{const p=normalizePort(input.value);if(p&&!seen.has(p)){addChip(prior,key,p,false);seen.add(p);}});block.remove();});
  }
  function addBlock(key,b){
    const wrap=document.querySelector(`[data-editor="${key}"]`);if(!wrap)return null;
    const block=document.createElement('div');block.className='tcp-ip-block';
    block.dataset.baseIp=normalizeIp(b.ip||'');block.dataset.isNew=b.isNew?'1':'0';
    const ports=(b.ports&&b.ports.length)?b.ports:[''];
    block.innerHTML=`<div class="tcp-ip-col">
        <label class="tcp-ip-label">Destination IP<input class="input tcp-ip-input" value="${esc(b.ip||'')}" placeholder="e.g. 10.0.0.1" autocomplete="off"></label>
        <span class="tcp-block-status"></span>
        <div class="tcp-ip-actions">
          <button type="button" class="btn small tcp-add-port" title="Add another port for this IP">＋ Port</button>
          <button type="button" class="btn small tcp-duplicate" title="Duplicate this IP block">Duplicate IP</button>
          <button type="button" class="btn small danger tcp-delete-ip" title="Delete this IP block">Delete IP</button>
        </div>
      </div>
      <div class="tcp-ports-col">
        <div class="tcp-ports-chips" data-chips></div>
        <button type="button" class="btn small tcp-add-port-inline">＋ Port</button>
      </div>`;
    ports.forEach(p=>addChip(block,key,p,false));
    const ipInput=block.querySelector('.tcp-ip-input');
    ipInput.addEventListener('input',()=>{blockStatus(block);updatePreview(key);});
    ipInput.addEventListener('blur',()=>{ipInput.value=normalizeIp(ipInput.value);blockStatus(block);dedupeDomBlocks(key);updatePreview(key);});
    block.querySelectorAll('.tcp-add-port,.tcp-add-port-inline').forEach(btn=>btn.addEventListener('click',()=>{
      const chip=addChip(block,key,'',true);updatePreview(key);chip?.querySelector('input')?.focus();
    }));
    block.querySelector('.tcp-duplicate').addEventListener('click',()=>{
      const blk=addBlock(key,{ip:normalizeIp(ipInput.value),ports:collectPorts(block,false),isNew:true,isModified:false});
      dedupeDomBlocks(key);updatePreview(key);blk?.querySelector('.tcp-ports-chips .tcp-port-chip input')?.focus();
    });
    block.querySelector('.tcp-delete-ip').addEventListener('click',()=>{block.remove();updatePreview(key);});
    wrap.appendChild(block);blockStatus(block);return block;
  }

  function addChip(block,key,port,isNew){
    const wrap=block.querySelector('[data-chips]');if(!wrap)return null;
    const chip=document.createElement('div');chip.className='tcp-port-chip';
    chip.dataset.basePort=normalizePort(port);
    chip.innerHTML=`<input class="input tcp-port-input" value="${esc(port)}" placeholder="80" inputmode="numeric" autocomplete="off"><span class="tcp-port-error"></span><button type="button" class="btn small danger tcp-port-del" title="Remove port" aria-label="Remove port">x</button>`;
    const input=chip.querySelector('input');
    const refresh=()=>{validateChip(chip);chipStatus(chip,block);updatePreview(key);};
    input.addEventListener('input',refresh);
    input.addEventListener('blur',()=>{input.value=normalizePort(input.value);refresh();});
    chip.querySelector('.tcp-port-del').addEventListener('click',()=>{chip.remove();updatePreview(key);});
    wrap.appendChild(chip);
    if(!isNew)validateChip(chip);
    return chip;
  }

  function validateChip(chip){
    const input=chip.querySelector('input'),val=normalizePort(input.value);
    const err=chip.querySelector('.tcp-port-error');
    let problem='';
    if(!val)problem='Enter a port (1–65535).';
    else if(!validPort(val))problem='Invalid port “'+val+'” — use 1 to 65535.';
    if(problem){chip.classList.add('tcp-port-invalid');err.textContent=problem;}
    else{chip.classList.remove('tcp-port-invalid');err.textContent='';}
    return !problem;
  }
  function collectPorts(block,validate=true){
    const out=[];let ok=true;
    block.querySelectorAll('.tcp-port-chip').forEach(chip=>{
      const val=normalizePort(chip.querySelector('input').value);
      if(!val&&!chip.querySelector('input').value.trim())return; /* fully empty chip ignored */
      if(validate&&!validateChip(chip))ok=false;
      if(val)out.push(val);
    });
    return validate&&ok?out:out;
  }
  function blockStatus(block){
    const badge=block.querySelector('.tcp-block-status');if(!badge)return;
    if(block.dataset.isNew==='1'){badge.textContent='New Line';badge.className='tcp-block-status badge-new';return;}
    const ip=normalizeIp(block.querySelector('.tcp-ip-input').value);
    const changed=ip!==normalizeIp(block.dataset.baseIp)||block.dataset.baseIp!==ip;
    const portsChanged=Array.from(block.querySelectorAll('.tcp-port-chip')).some(c=>normalizePort(c.querySelector('input').value)!==normalizePort(c.dataset.basePort));
    const mod=changed||portsChanged;
    badge.textContent=mod?'Modified':'';badge.className='tcp-block-status'+(mod?' badge-mod':'');
  }
  function chipStatus(){/* handled by validateChip + blockStatus */}

  function collectBlocks(key,validate=true){
    const wrap=document.querySelector(`[data-editor="${key}"]`),out=[];
    if(!wrap)return out;dedupeDomBlocks(key);let ok=true;
    for(const block of wrap.querySelectorAll('.tcp-ip-block')){
      const ip=normalizeIp(block.querySelector('.tcp-ip-input').value);
      const ports=[];let blockOk=true;
      block.querySelectorAll('.tcp-port-chip').forEach(chip=>{
        const raw=chip.querySelector('input').value,val=normalizePort(raw);
        if(!raw.trim())return;
        if(!validPort(val)){blockOk=false;if(validate)validateChip(chip);}
        else if(val&&!ports.includes(val))ports.push(val);
      });
      const firstInput=block.querySelector('.tcp-port-chip input');
      if(!ip&&!ports.length&&(!firstInput||!firstInput.value.trim()))continue; /* fully empty block skipped */
      if(validate){
        if(!ip){ok=false;msg(`[${key}] Enter an IP for every destination block.`,'error');}
        else if(!ports.length){ok=false;msg(`[${key}] Add at least one port for ${ip}.`,'error');}
        else if(/[\s,]/.test(ip)){ok=false;msg(`[${key}] IP/host cannot contain commas or whitespace.`,'error');}
        else if(!blockOk){ok=false;msg(`[${key}] Fix invalid port values (1–65535).`,'error');}
      }
      if(!ip&&!ports.length)continue;
      out.push({ip,ports,isNew:block.dataset.isNew==='1',isModified:false});
    }
    return validate&&!ok?null:out;
  }

  function updatePreview(key){
    const wrap=document.querySelector(`[data-editor="${key}"]`),out=document.querySelector(`[data-preview="${key}"]`);
    if(!wrap||!out)return;
    const blocks=collectBlocks(key,false)||[];
    const s=serializeBlocks(blocks);
    out.innerHTML=`<span>LLD macro payload</span><code>${esc(wrap.dataset.ipMacro)} = ${esc(s.ips||'(empty)')}</code><code>${esc(wrap.dataset.portMacro)} = ${esc(s.ports||'(empty)')}</code>`;
  }

  async function selectHost(id){
    state.selected=String(id);renderHosts();
    const d=$('tcpHostDetails'),e=$('tcpPairEditor');
    if(d)d.innerHTML='Loading…';if(e)e.innerHTML='Loading…';msg('');
    try{const data=await post('/api/tcp_host_details',{hostid:String(id)});state.details=data.host;renderDetails();}
    catch(err){console.error('[TCP] host details request failed',err);if(d)d.innerHTML=`<div class="tcp-warning">${esc(err.message||err)}</div>`;if(e)e.innerHTML='Unable to load editors';}
  }

  function initTcpCheckControls(){
    if(state.wired)return;state.wired=true;
    $('tcpHostSearch')?.addEventListener('input',renderHosts);
    $('tcpTemplateFilter')?.addEventListener('change',()=>{const b=$('tcpTemplateFilterBadge');if(b)b.textContent=$('tcpTemplateFilter').value||'All templates';renderHosts();});
    $('tcpRefreshBtn')?.addEventListener('click',loadTcpHosts);
    $('tcpExportReportBtn')?.addEventListener('click',exportHostReport);
    $('tcpSaveBtn')?.addEventListener('click',saveMacros);
  }

  async function saveMacros(){
    if(!state.selected||!state.details){msg('Select a host first.','error');return;}
    const btn=$('tcpSaveBtn');if(btn?.disabled)return;
    try{
      const groups={},macros={};
      const mode=($('tcpPairEditor')?.dataset.mode)||detectHostMode(state.details);
      const isShown=key=>{
        const wrap=document.querySelector(`[data-editor="${key}"]`);
        if(!wrap)return false; /* hidden/absent section must never be wiped */
        const sec=wrap.closest('[data-section]');
        return !sec||sec.style.display!=='none';
      };
      for(const key of Object.keys(CONF)){
        if(!isShown(key)){
          /* Preserve existing macro values for hidden sections. */
          const [im,pm]=keyMacros(key);
          const preserved=serializeBlocks(macroPairs(im,pm));
          groups[key]=preserved;
          macros[CONF[key].ipMacro]=preserved.ips;macros[CONF[key].portMacro]=preserved.ports;
          continue;
        }
        const blocks=collectBlocks(key,true);
        if(blocks===null)throw new Error('Please fix the highlighted port fields before saving.');
        const s=serializeBlocks(blocks);
        groups[key]=s;
        macros[CONF[key].ipMacro]=s.ips;macros[CONF[key].portMacro]=s.ports;
      }
      const total=Object.values(groups).reduce((a,s)=>a+s.count,0);
      if(total===0&&!window.confirm('All TCP destinations are empty/deleted. Save empty macro values?'))return;
      const payload={hostid:String(state.selected),macros};
      if(btn)btn.disabled=true;msg('Saving TCP macros…','');
      console.info('[TCP] saving macro payload',payload);
      const data=await post('/api/tcp_update_macros',payload);
      const count=data.results?.length||0;
      msg(`Saved ${count} TCP macro(s).`,'success');
      console.info('[TCP] save succeeded',data);
      await selectHost(state.selected);
    }catch(e){console.error('[TCP] save failed',e);msg(e.message||String(e),'error');}
    finally{if(btn)btn.disabled=false;}
  }

  /* ---------- host report CSV ---------- */
  function macroPairsOn(host, ipMacro, portMacro){
    const read=name=>{const v=host&&host.macros?host.macros[name]:null;const raw=(v&&typeof v==='object'&&'value' in v)?v.value:v;
      return normalizeText(raw==null?'':raw).split(',').map(x=>x.trim()).filter(Boolean);};
    const ips=read(ipMacro),ports=read(portMacro),n=Math.max(ips.length,ports.length);
    return blocksFromPairs(Array.from({length:n},(_,i)=>({ip:ips[i]||'',port:ports[i]||''})));
  }
  function buildHostReportCsv(target) {
    const hosts = Array.isArray(target) ? target : (target ? [target] : []);
    const rows = [['Hostname', 'Visible Name', 'Scope', 'Target IP', 'Monitored Ports']];
    for (const h of hosts) {
      const mode = detectHostMode(h);
      const blocks = [];
      if (mode === 'inext' || mode === 'both') {
        const intPairs = macroPairsOn(h, '{$DST_IP_INTERNAL}', '{$DST_PORT_INTERNAL}');
        for (const p of intPairs) blocks.push({ scope: 'Internal', ip: p.ip, ports: p.ports.join(',') });
        const extPairs = macroPairsOn(h, '{$DST_IP_EXTERNAL}', '{$DST_PORT_EXTERNAL}');
        for (const p of extPairs) blocks.push({ scope: 'External', ip: p.ip, ports: p.ports.join(',') });
      }
      if (mode === 'agent' || mode === 'both') {
        const agentPairs = macroPairsOn(h, '{$DST_IP}', '{$DST_PORT}');
        for (const p of agentPairs) blocks.push({ scope: 'General', ip: p.ip, ports: p.ports.join(',') });
      }
      if (!blocks.length) {
        rows.push([h.host || '', h.name || '', 'None', '', '']);
      } else {
        for (const b of blocks) rows.push([h.host || '', h.name || '', b.scope, b.ip, b.ports]);
      }
    }
    return '\uFEFF' + rows.map(r => r.map(c => `"${String(c == null ? '' : c).replace(/"/g, '""')}"`).join(',')).join('\r\n');
  }
  async function exportHostReport(){
    if(!state.selected){
      alert('لطفاً ابتدا یک هاست را از لیست انتخاب کنید (Please select a host first).');
      return;
    }
    const host=state.details||state.hosts.find(h=>String(h.hostid)===String(state.selected));
    const btn=document.getElementById('tcpExportReportBtn');
    try{
      if(btn)btn.disabled=true;
      const headers={'Content-Type':'application/json'};
      if(typeof currentSessionToken!=='undefined' && currentSessionToken){
        headers['X-Importer-Session']=currentSessionToken;
      }
      const response=await fetch('/api/export-report',{method:'POST',headers,body:JSON.stringify({hosts:host?[host]:[]})});
      if(!response.ok){
        let message='HTTP '+response.status;
        try{const data=await response.json();message=data.error||data.message||message;}catch(_){ }
        throw new Error(message);
      }
      const blob=await response.blob();
      const a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download='zabbix_tcp_report.xlsx';
      document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(a.href),1000);
      msg('Excel report exported.','success');
    }catch(e){
      console.error('[TCP] report export failed',e);
      msg(e.message||String(e),'error');
    }finally{if(btn)btn.disabled=false;}
  }

  /* Expose internals for tests/tooling. */
  window.TcpCheckInternals={normalizeText,normalizePort,normalizeIp,validPort,blocksFromPairs,serializeBlocks,macroPairs,parseBulkTargets,mergeTargetsIntoBlocks,dedupeTargets,buildHostReportCsv,detectHostMode,templateBadge,macroTargetIps,exportHostReport,state,renderHosts}
  if (typeof module!=='undefined' && module.exports){
    module.exports={normalizeText, normalizePort, normalizeIp, validPort, blocksFromPairs, serializeBlocks, macroPairs, parseBulkTargets, mergeTargetsIntoBlocks, dedupeTargets, buildHostReportCsv, detectHostMode, templateBadge, macroTargetIps, exportHostReport, state, renderHosts};
  }
;

  window.initTcpCheckControls=initTcpCheckControls;window.loadTcpHosts=loadTcpHosts;
})();
