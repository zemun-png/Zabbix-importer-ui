/* Single host controller */
function setSingleMessage(text, type = '') {
    const e = $('singleMessage');
    if (!e) return;
    if (!text) { e.style.display = 'none'; e.textContent = ''; return; }
    e.textContent = text;
    e.className = 'msg' + (type ? ' ' + type : '');
    e.style.display = 'block';
}

function updateSinglePreview() {
    const b = $('singleBaseHost'), p = $('singleLivePreview');
    if (b && p) p.textContent = finalHost(b.value.trim()) || '(Enter a base hostname)';
}

let ifaceCount = 0;

function ensureSingleSnmpV3Macros() {
    const list=$('macrosList'); if(!list)return;
    [['{$SNMP_USER}',0],['{$SNMP_AUTH_PASS}',1],['{$SNMP_PRIV_PASS}',1]].forEach(([name,type])=>{
        const exists=[...list.querySelectorAll('.macro-name')].some(x=>x.value.trim().toUpperCase()===name);
        if(!exists)window.addMacroRow?.(name,'','',type);
        const row=[...list.querySelectorAll('.macro-row')].find(r=>r.querySelector('.macro-name')?.value.trim().toUpperCase()===name);
        if(row&&row.querySelector('.macro-type'))row.querySelector('.macro-type').value=String(type);
    });
}
function addSingleInterfaceCard(initial = {}) {
    const container = $('singleInterfacesList');
    if (!container) return;
    ifaceCount++;
    const card = document.createElement('div');
    card.className = 'iface-card';
    const type = String(initial.type || '1');
    const port = initial.port || defaultPorts[type] || '10050';
    card.innerHTML = `<div class="iface-head"><span class="iface-title">Interface #${ifaceCount}</span><button type="button" class="btn danger small iface-del-btn">Remove</button></div><div class="grid4"><div class="field"><label>Type</label><select class="input iface-type"><option value="1" ${type==='1'?'selected':''}>1 - Zabbix Agent</option><option value="2" ${type==='2'?'selected':''}>2 - SNMP</option><option value="3" ${type==='3'?'selected':''}>3 - IPMI</option><option value="4" ${type==='4'?'selected':''}>4 - JMX</option></select></div><div class="field"><label>IP Address</label><input class="input iface-ip" placeholder="192.168.1.1" value="${escapeHtml(initial.ip||'')}"></div><div class="field"><label>DNS Name</label><input class="input iface-dns" placeholder="host.domain" value="${escapeHtml(initial.dns||'')}"></div><div class="field"><label>Port / {$PORT}</label><input class="input iface-port" value="${escapeHtml(port)}"></div></div><div class="snmp-box iface-snmp-wrap" style="display:none"><div class="grid2" style="margin-bottom:8px"><div class="field"><label>SNMP Version</label><select class="input iface-snmp-ver"><option value="2" selected>SNMPv2c</option><option value="1">SNMPv1</option><option value="3">SNMPv3</option></select></div><div class="field iface-snmp-comm-wrap"><label>SNMP Community / {$MACRO}</label><input class="input iface-snmp-comm" value="{$SNMP_COMMUNITY}" placeholder="public or {$SNMP_COMMUNITY}"></div></div><div class="iface-snmp3-wrap" style="display:none"><div class="grid3"><div class="field"><label>Security Name</label><input class="input iface-snmp3-user" placeholder="Security name or {$SNMP_USER}"></div><div class="field"><label>Security Level</label><select class="input iface-snmp3-level"><option value="0">0 - noAuthNoPriv</option><option value="1">1 - authNoPriv</option><option value="2" selected>2 - authPriv</option></select></div><div class="field"><label>Context Name</label><input class="input iface-snmp3-ctx" placeholder="Optional or {$SNMP_CONTEXT}"></div></div><div class="grid2" style="margin-top:6px"><div class="field"><label>Auth Protocol</label><select class="input iface-snmp3-auth-proto"><option value="0">MD5</option><option value="1">SHA1</option><option value="2">SHA224</option><option value="3" selected>SHA256</option><option value="4">SHA384</option><option value="5">SHA512</option></select></div><div class="field"><label>Auth Passphrase</label><input class="input iface-snmp3-auth-pass" placeholder="Passphrase or {$SNMP_AUTH_PASS}"></div></div><div class="grid2" style="margin-top:6px"><div class="field"><label>Privacy Protocol</label><select class="input iface-snmp3-priv-proto"><option value="0">DES</option><option value="1" selected>AES128</option><option value="2">AES192</option><option value="3">AES256</option><option value="4">AES192C</option><option value="5">AES256C</option></select></div><div class="field"><label>Privacy Passphrase</label><input class="input iface-snmp3-priv-pass" placeholder="Passphrase or {$SNMP_PRIV_PASS}"></div></div></div></div>`;

    const ts = card.querySelector('.iface-type');
    const vs = card.querySelector('.iface-snmp-ver');
    const pi = card.querySelector('.iface-port');
    function update() {
        const sn = ts.value === '2';
        const v3 = sn && vs.value === '3';
        if(v3)ensureSingleSnmpV3Macros();
        card.querySelector('.iface-snmp-wrap').style.display = sn ? 'block' : 'none';
        card.querySelector('.iface-snmp-comm-wrap').style.display = sn && !v3 ? 'block' : 'none';
        card.querySelector('.iface-snmp3-wrap').style.display = v3 ? 'block' : 'none';
    }
    ts.onchange = () => { pi.value = defaultPorts[ts.value] || '10050'; update(); };
    vs.onchange = update;
    card.querySelector('.iface-del-btn').onclick = () => card.remove();
    container.appendChild(card);
    update();
}

function getSingleInterfaces() {
    return [...document.querySelectorAll('#singleInterfacesList .iface-card')].map((c, i) => {
        const type = parseInt(c.querySelector('.iface-type').value, 10);
        const ip = c.querySelector('.iface-ip').value.trim();
        const dns = c.querySelector('.iface-dns').value.trim();
        const iface = {
            type,
            main: i === 0 ? 1 : 0,
            useip: ip ? 1 : 0,
            ip: ip || (dns ? '' : '127.0.0.1'),
            dns: dns || '',
            port: c.querySelector('.iface-port').value.trim() || defaultPorts[type] || '10050'
        };
        if (type === 2) {
            /* SNMP detail values (community, securityname, passphrases, context) are sent
               to the Zabbix API exactly as typed - plain strings or {$MACRO} expressions
               are both preserved. */
            const version = parseInt(c.querySelector('.iface-snmp-ver').value, 10);
            const d = { version };
            if (version === 3) {
                const level = parseInt(c.querySelector('.iface-snmp3-level').value, 10);
                d.securityname = c.querySelector('.iface-snmp3-user').value.trim();
                d.securitylevel = level;
                d.contextname = c.querySelector('.iface-snmp3-ctx').value.trim();
                if (level >= 1) {
                    d.authprotocol = parseInt(c.querySelector('.iface-snmp3-auth-proto').value, 10);
                    d.authpassphrase = c.querySelector('.iface-snmp3-auth-pass').value.trim();
                }
                if (level === 2) {
                    d.privprotocol = parseInt(c.querySelector('.iface-snmp3-priv-proto').value, 10);
                    d.privpassphrase = c.querySelector('.iface-snmp3-priv-pass').value.trim();
                }
            } else {
                d.community = c.querySelector('.iface-snmp-comm').value.trim() || '{$SNMP_COMMUNITY}';
            }
            iface.details = d;
        }
        return iface;
    });
}

function normMacroName(n) {
    n = (n || '').trim();
    if (!n) return '';
    if (/^\{\$[A-Z0-9_.]+\}$/i.test(n)) return n.toUpperCase();
    const inner = n.replace(/^\{\$/, '').replace(/\}$/, '').replace(/[^A-Za-z0-9_.]/g, '_');
    return inner ? ('{$' + inner.toUpperCase() + '}') : '';
}

function isValidMacroName(n) {
    return /^\{\$[A-Z0-9_.]+\}$/.test(n);
}

window.updateSingleSelectionSummary = function () {
    const box = $('singleSelectionSummary');
    if (!box) return;
    const g = [...state.selectedGroups];
    const t = [...state.selectedTemplates];
    const px = $('proxy');
    const gNames = g.map(id => {
        const m = (state.metadata.groups || []).find(x => String(x.groupid) === String(id));
        return m ? m.name : id;
    });
    const tNames = t.map(id => {
        const m = (state.metadata.templates || []).find(x => String(x.templateid) === String(id));
        return m ? m.name : id;
    });
    if (!g.length && !t.length && !(px && px.value)) {
        box.innerHTML = '<div class="sel-summary-empty">No Host Groups or Templates selected yet</div>';
        return;
    }
    const esc = escapeHtml;
    let html = '';
    html += '<div class="sel-row"><span class="sel-label">Proxy:</span>' +
        (px && px.value
            ? '<span class="sel-badge proxy">' + esc(px.selectedOptions?.[0]?.textContent || px.value) + '</span>'
            : '<span class="sel-empty">Direct (no proxy)</span>') + '</div>';
    html += '<div class="sel-row"><span class="sel-label">Groups (' + g.length + '):</span>' +
        (g.length ? gNames.map(n => '<span class="sel-badge group" title="' + esc(n) + '">' + esc(n) + '</span>').join('')
                  : '<span class="sel-empty">none</span>') + '</div>';
    html += '<div class="sel-row"><span class="sel-label">Templates (' + t.length + '):</span>' +
        (t.length ? tNames.map(n => '<span class="sel-badge template" title="' + esc(n) + '">' + esc(n) + '</span>').join('')
                  : '<span class="sel-empty">none</span>') + '</div>';
    box.innerHTML = html;
};

function getTemplateMacroOverrides() {
    return Array.from(document.querySelectorAll('#templateMacros .tm-row'))
        .map(r => { const input=r.querySelector('.tm-val'); return {
            macro: r.querySelector('.tm-name')?.dataset.macro || r.querySelector('.tm-name')?.textContent || '',
            value: (input?.value || '').trim(), defaultValue: input?.dataset.default ?? '',
            type: parseInt(r.querySelector('.macro-type')?.value || 0, 10)
        }; })
        .filter(x => x.macro && x.value !== x.defaultValue)
        .map(x => ({ macro: normMacroName(x.macro), value: x.value, type: x.type }))
        .filter(x => isValidMacroName(x.macro));
}

function getMergedMacros() {
    const seen = {};
    const out = [];
    getHostMacros().concat(getTemplateMacroOverrides()).forEach(m => {
        const k = normMacroName(m.macro);
        if (!k || !isValidMacroName(k) || seen[k]) return;
        seen[k] = 1;
        out.push({ macro: k, value: m.value, type: parseInt(m.type || 0, 10) || 0, ...(m.description ? { description: m.description } : {}) });
    });
    return out;
}

function addValueMapMappingRow() {
    const list = $('singleValueMapMappings');
    if (!list) return;
    const row = document.createElement('div');
    row.className = 'grid4 value-map-row';
    row.style.marginBottom = '6px';
    row.innerHTML = `<select class="input vm-type" aria-label="Mapping type"><option value="0">Equals</option><option value="1">Greater than or equal</option><option value="2">Less than or equal</option><option value="3">In range</option><option value="4">Regular expression</option><option value="5">Default</option></select><input class="input vm-value" placeholder="Value / range / regexp"><input class="input vm-newvalue" placeholder="Mapped value"><button type="button" class="btn danger small vm-remove">Remove</button>`;
    row.querySelector('.vm-remove').onclick = () => row.remove();
    row.querySelector('.vm-type').onchange = () => { row.querySelector('.vm-value').disabled = row.querySelector('.vm-type').value === '5'; };
    list.appendChild(row);
}

function getSingleValueMaps() {
    const name = $('singleValueMapName')?.value.trim() || '';
    if (!name) return { valuemaps: [], error: null };
    const mappings = Array.from(document.querySelectorAll('#singleValueMapMappings .value-map-row')).map(row => ({
        type: parseInt(row.querySelector('.vm-type')?.value || '0', 10),
        value: row.querySelector('.vm-value')?.value.trim() || '',
        newvalue: row.querySelector('.vm-newvalue')?.value.trim() || ''
    }));
    if (!mappings.length || mappings.some(m => !m.newvalue || (m.type !== 5 && !m.value))) {
        return { valuemaps: [], error: 'Value map has incomplete mappings. Enter a mapped value and, except for Default mappings, a value.' };
    }
    return { valuemaps: [{ name, mappings }], error: null };
}

function initSingleHostControls() {
    initDefaultTags('tagsList');
    if ($('addValueMapMapping')) $('addValueMapMapping').onclick = addValueMapMappingRow;
    const valueMapMappings = $('singleValueMapMappings');
    if (valueMapMappings && !valueMapMappings.querySelector('.value-map-row')) addValueMapMappingRow();
    const b = $('singleBaseHost');
    if (b) {
        b.addEventListener('input', updateSinglePreview);
        b.addEventListener('change', updateSinglePreview);
    }
    updateSinglePreview();
    if ($('proxy')) {
        $('proxy').addEventListener('change', () => window.updateSingleSelectionSummary && window.updateSingleSelectionSummary());
    }
    if ($('addSingleInterface')) $('addSingleInterface').onclick = () => addSingleInterfaceCard();
    if ($('addTagBtn')) $('addTagBtn').onclick = () => addTagPair();
    if ($('addMacroBtn')) $('addMacroBtn').onclick = () => addMacroRow();

    const btn = $('singleCreateBtn');
    if (!btn) return;
    btn.onclick = async () => {
        setSingleMessage('');
        try {
            const base = b?.value.trim() || '';
            if (!base) throw Error('Please enter a base hostname.');
            const name = finalHost(base);
            if (!state.selectedGroups.size) throw Error('Please select at least one Host Group from Section 2.');
            const templates = [...state.selectedTemplates];
            const macros = getMergedMacros();
            const interfaces = getSingleInterfaces();
            if (!interfaces.length) throw Error('Please add at least one Network Interface.');
            interfaces.forEach((x, i) => {
                if (!x.ip && !x.dns) throw Error(`Interface #${i + 1} requires either an IP address or a DNS name.`);
            });
            const payload = {
                host: name,
                status: parseInt($('singleHostStatus')?.value || '0', 10),
                groups: [...state.selectedGroups].map(groupid => ({ groupid })),
                interfaces,
                tags: getTags('tagsList'),
                templates: templates.map(templateid => ({ templateid }))
            };
            if (templates.length) payload.templates = templates.map(templateid => ({ templateid }));
            if (macros.length) payload.macros = macros;
            const valueMapResult = getSingleValueMaps();
            if (valueMapResult.error) throw Error(valueMapResult.error);
            if (valueMapResult.valuemaps.length) payload.valuemaps = valueMapResult.valuemaps;
            if ($('proxy')?.value) { const pv=$('proxy').value; if(pv.startsWith('pg:')) payload.proxy_groupid=pv.slice(3); else if(pv.startsWith('p:')) { payload.proxyid=pv.slice(2); payload.proxy_hostid=pv.slice(2); } }
            btn.disabled = true;
            setSingleMessage(`Creating host "${name}" in Zabbix...`);
            const res = await api('/api/import', { method: 'POST', body: JSON.stringify({ hosts: [payload] }) });
            const r = res.results?.[0] || {};
            if (r.status === 'OK') {
                setSingleMessage(`[SUCCESS] Host "${name}" created successfully! (Host ID: ${r.hostid})`, 'success');
                b.value = '';
                updateSinglePreview();
            } else {
                setSingleMessage(`[ERROR] Failed to create host:\n${typeof r.error === 'string' ? r.error : JSON.stringify(r.error || 'Failed to create host', null, 2)}`, 'error');
            }
        } catch (e) {
            setSingleMessage(`[ERROR] ${e.message}`, 'error');
        } finally {
            btn.disabled = false;
        }
    };
}
