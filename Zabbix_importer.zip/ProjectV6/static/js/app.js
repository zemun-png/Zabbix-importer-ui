let currentSessionToken = null;
const LOGIN_TIMEOUT_MS = 20000;
if (!window.state) window.state = { rows: [], metadata: { groups: [], templates: [], proxies: [] }, importing: false, selectedGroups: new Set(), selectedTemplates: new Set() };
else { window.state.metadata = window.state.metadata || {}; window.state.metadata.groups = window.state.metadata.groups || []; window.state.metadata.templates = window.state.metadata.templates || []; window.state.metadata.proxies = window.state.metadata.proxies || []; }
function $(id) { return document.getElementById(id); }
function esc(s) { return s == null ? '' : String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
async function readApiResponse(res) {
    const text = await res.text();
    let data = {};
    if (text) { try { data = JSON.parse(text); } catch (_) { if (res.ok) throw new Error('Server returned a non-JSON response (HTTP ' + res.status + ').'); } }
    if (!data || typeof data !== 'object') data = {};
    if (!res.ok) throw new Error(data.error || data.message || ('HTTP ' + res.status));
    return data;
}
async function api(url, opts = {}) {
    const headers = Object.assign({}, opts.headers || {});
    if (currentSessionToken) headers['X-Importer-Session'] = currentSessionToken;
    let res;
    try { res = await fetch(url, Object.assign({}, opts, { headers })); }
    catch (e) { throw new Error('Network error calling ' + url + ': ' + (e.message || e)); }
    return readApiResponse(res);
}
async function loadMetadata() {
    const data = await api('/api/metadata');
    if (!data || typeof data !== 'object' || !Array.isArray(data.groups) || !Array.isArray(data.templates)) throw new Error('Metadata response is missing groups or templates.');
    state.metadata = Object.assign({ groups: [], templates: [], proxies: [] }, data);
    state.metadata.groups = state.metadata.groups || []; state.metadata.templates = state.metadata.templates || []; state.metadata.proxies = state.metadata.proxies || [];
    if (typeof initPickerControls === 'function') initPickerControls();
    if (typeof initBulkPickers === 'function') initBulkPickers();
    renderProxySelect();
    if (typeof updateGroupCount === 'function') updateGroupCount();
    if (typeof updateTemplateCount === 'function') updateTemplateCount();
    if (typeof updateBulkPickerCounts === 'function') updateBulkPickerCounts();
    if (typeof updateSingleSelectionSummary === 'function') updateSingleSelectionSummary();
    if (typeof loadTcpHosts === 'function' && currentSessionToken) loadTcpHosts();
    return data;
}
function renderProxySelect() { if (typeof fillProxySelect === 'function') { fillProxySelect($('proxy'), state.metadata.proxies || [], state.metadata.proxy_groups || []); fillProxySelect($('bulkProxy'), state.metadata.proxies || [], state.metadata.proxy_groups || []); } }
function initNamingControls() { if (typeof window.updateNamingPreview === 'function') window.updateNamingPreview(); }
function wireTabSwitching() {
    const buttons = Array.from(document.querySelectorAll('.tab-btn, [data-tab]'));
    buttons.forEach(button => { if (button.dataset.tabWired === '1') return; button.dataset.tabWired = '1'; button.addEventListener('click', () => {
        const targetId = button.dataset.tab; if (!targetId) return;
        buttons.forEach(b => b.classList.toggle('active', b === button));
        document.querySelectorAll('.tab-content').forEach(section => { const active = section.id === targetId; section.classList.toggle('active', active); section.hidden = !active; });
        if (targetId === 'tabBulk' && typeof renderTable === 'function') renderTable();
    }); });
}
function setAuthUI(connected, message, username) {
    const badge = $('authStatusBadge'), wrapper = $('mainAppWrapper'), msg = $('authMessage');
    if (msg) msg.textContent = message || '';
    const dot = $('connectionDot'), text = $('connectionText');
    if (connected) { if (badge) { badge.className='badge bg-success'; badge.textContent='Connected ('+(username||'user')+')'; } if(wrapper)wrapper.classList.remove('locked-app'); if(dot)dot.className='dot ok'; if(text)text.textContent='Connected'; }
    else { if (badge) { badge.className='badge bg-secondary'; badge.textContent='Disconnected'; } if(wrapper)wrapper.classList.add('locked-app'); if(dot)dot.className='dot bad'; if(text)text.textContent='Disconnected'; }
}

function getAuthMode() {
    const checked = document.querySelector('input[name="authMode"]:checked');
    return checked ? checked.value : 'credentials';
}
function applyAuthModeVisibility() {
    const mode = getAuthMode();
    document.querySelectorAll('.auth-cred-field').forEach(el => { el.style.display = (mode === 'token') ? 'none' : ''; });
    const tf = document.querySelector('.auth-token-field');
    if (tf) tf.style.display = (mode === 'token') ? '' : 'none';
    const tok = $('zabbixToken');
    if (tok) { tok.type = 'password'; }
}
function wireAuthModeToggle() {
    document.querySelectorAll('input[name="authMode"]').forEach(radio => {
        if (radio.dataset.authWired === '1') return;
        radio.dataset.authWired = '1';
        radio.addEventListener('change', () => { if (radio.checked) applyAuthModeVisibility(); });
    });
    applyAuthModeVisibility();
}
window.getAuthMode = getAuthMode; window.applyAuthModeVisibility = applyAuthModeVisibility;

async function connectZabbix() {
    const button = $('btnConnect');
    const url = $('zabbixUrl') ? $('zabbixUrl').value.trim() : '', user = $('zabbixUser') ? $('zabbixUser').value.trim() : '';
    const password = $('zabbixPassword') ? $('zabbixPassword').value : '', tokenRaw = $('zabbixToken') ? $('zabbixToken').value.trim() : '';
    const authMode = getAuthMode();
    const useToken = authMode === 'token';
    const token = useToken ? tokenRaw : '', username = useToken ? '' : user, passwordFinal = useToken ? '' : password;
    if (useToken && !token) { setAuthUI(false, 'Please enter an API token.', ''); if (button) button.disabled = false; return; }
    if (!useToken && (!username || !passwordFinal)) { setAuthUI(false, 'Please enter a username and password.', ''); if (button) button.disabled = false; return; }
    if (button) button.disabled = true;
    setAuthUI(false, 'Connecting...', '');
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), LOGIN_TIMEOUT_MS);
    try {
        const res = await fetch('/api/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url,username,password:passwordFinal,token}), signal:controller.signal });
        const data = await readApiResponse(res);
        const sessionToken = data.session || data.session_id;
        if (!sessionToken) throw new Error('Login response did not include a session.');
        currentSessionToken = sessionToken;
        window.currentSessionToken = currentSessionToken;
        setAuthUI(true, 'Authenticated. Loading groups and templates...', data.username || (useToken ? 'API Token User' : user));
        try { await loadMetadata(); setAuthUI(true, 'Connected; metadata loaded.', data.username || (useToken ? 'API Token User' : user)); }
        catch (e) { setAuthUI(true, 'Authenticated, but metadata could not be loaded: ' + (e.message || e), data.username || (useToken ? 'API Token User' : user)); }
    } catch (e) {
        currentSessionToken = null;
        const msg = e && e.name === 'AbortError' ? 'Login timed out after ' + Math.round(LOGIN_TIMEOUT_MS/1000) + ' seconds.' : (e.message || String(e));
        setAuthUI(false, 'Connection failed: ' + msg, '');
    } finally { clearTimeout(timer); if (button) button.disabled = false; }
}
window.api=api; window.setAuthUI=setAuthUI; window.loadMetadata=loadMetadata; window.renderProxySelect=renderProxySelect; window.wireTabSwitching=wireTabSwitching; window.connectZabbix=connectZabbix;
function initialize() {
    const btn=$('btnConnect');
    if(btn && btn.dataset.connectWired!=='1') { btn.dataset.connectWired='1'; btn.type='button'; btn.addEventListener('click', e=>{e.preventDefault(); connectZabbix();}); }
    document.querySelectorAll('form').forEach(form=>{ if(form.dataset.submitGuard!=='1'){form.dataset.submitGuard='1';form.addEventListener('submit',e=>e.preventDefault());} });
    for(const fn of [wireAuthModeToggle,wireTabSwitching,initNamingControls,()=>{if(typeof initSingleHostControls==='function')initSingleHostControls();},()=>{if(typeof initBulkControls==='function')initBulkControls();},()=>{if(typeof initTcpCheckControls==='function')initTcpCheckControls();}]) { try { fn(); } catch(e) { console.error('Importer initialization error:',e); const m=$('authMessage'); if(m)m.textContent='UI initialization warning: '+(e.message||e); } }
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initialize,{once:true}); else initialize();
