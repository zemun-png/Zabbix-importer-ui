"""Styled, merged-cell Excel report for Zabbix TCP destinations."""
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

HEADERS = ("Hostname", "Visible Name", "Host IP", "Scope", "Target IP", "Monitored Ports")
HEADER_FILL = "D9C3B0"
SCOPE_FILLS = {"Internal": "DDEBF7", "External": "E2EFDA", "General": "FFF2CC", "None": "E7E6E6"}
THIN = Side(style="thin", color="AAB7C4")

def _value(value):
    if isinstance(value, dict): value = value.get("value", "")
    return str(value if value is not None else "").strip()

def _pairs(macros, ip_key, port_key):
    ips = [v.strip() for v in _value(macros.get(ip_key)).split(",")]
    ports = [v.strip() for v in _value(macros.get(port_key)).split(",")]
    out = []
    for i in range(max(len(ips), len(ports))):
        ip, port = ips[i] if i < len(ips) else "", ports[i] if i < len(ports) else ""
        if ip or port:
            if ip and any(item["ip"] == ip for item in out):
                next(item for item in out if item["ip"] == ip)["ports"].append(port) if port else None
            else: out.append({"ip": ip, "ports": [port] if port else []})
    return out

def host_ip_from_row(host):
    """Host IP from row fields with precedence host_ip, interface_ip, ip,
    host_ip_address; empty string when none is present."""
    if not isinstance(host, dict):
        return ""
    for key in ("host_ip", "interface_ip", "ip", "host_ip_address"):
        val = _value(host.get(key))
        if val:
            return val
    return ""

def _host_blocks(host):
    macros = host.get("macros") if isinstance(host.get("macros"), dict) else {}
    templates = host.get("tcp_templates") or host.get("templates") or []
    names = [str(t.get("name", "") if isinstance(t, dict) else t) for t in templates]
    has_inext = any("INEXT" in n.upper() for n in names) or any(k in macros for k in ("{$DST_IP_INTERNAL}", "{$DST_PORT_INTERNAL}", "{$DST_IP_EXTERNAL}", "{$DST_PORT_EXTERNAL}"))
    has_agent = any("INEXT" not in n.upper() for n in names) or any(k in macros for k in ("{$DST_IP}", "{$DST_PORT}"))
    blocks=[]
    if has_inext:
        for scope, ik, pk in (("Internal", "{$DST_IP_INTERNAL}", "{$DST_PORT_INTERNAL}"), ("External", "{$DST_IP_EXTERNAL}", "{$DST_PORT_EXTERNAL}")):
            blocks.extend({"scope":scope, **pair} for pair in _pairs(macros, ik, pk))
    if has_agent:
        blocks.extend({"scope":"General", **pair} for pair in _pairs(macros, "{$DST_IP}", "{$DST_PORT}"))
    return blocks or [{"scope":"None", "ip":"", "ports":[]}]

def build_report_workbook(hosts):
    """Build in-memory xlsx. Hostname and visible name span all destination rows per host."""
    hosts = hosts if isinstance(hosts, list) else ([hosts] if hosts else [])
    wb=Workbook(); ws=wb.active; ws.title="Hosts Report"; ws.freeze_panes="D2"; ws.auto_filter.ref="A1:F1"
    ws.sheet_view.showGridLines=True
    for col, title in enumerate(HEADERS, 1):
        c=ws.cell(1,col,title); c.fill=PatternFill("solid", fgColor=HEADER_FILL); c.font=Font(name="Calibri", size=11, bold=True, color="000000")
        c.alignment=Alignment(horizontal="center", vertical="center", wrap_text=True); c.border=Border(left=THIN,right=THIN,top=THIN,bottom=THIN)
    ws.row_dimensions[1].height=25
    row=2
    for host in hosts:
        if not isinstance(host,dict): continue
        start=row; blocks=_host_blocks(host)
        for b in blocks:
            ws.cell(row,3,host_ip_from_row(host)); ws.cell(row,4,b["scope"]); ws.cell(row,5,b["ip"]); ws.cell(row,6,", ".join(b["ports"]))
            fill=SCOPE_FILLS.get(b["scope"],SCOPE_FILLS["None"])
            for col in range(1,7):
                cell=ws.cell(row,col); cell.border=Border(left=THIN,right=THIN,top=THIN,bottom=THIN)
                cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
                if col==4: cell.fill=PatternFill("solid",fgColor=fill);cell.font=Font(name="Calibri",size=11,color="2F5B7C",bold=True)
                elif col==6: cell.fill=PatternFill("solid",fgColor="EAF1FB");cell.font=Font(name="Calibri",size=11,color="1F4E79")
                else: cell.font=Font(name="Calibri",size=11,color="3B3B3B" if col<3 else "44546A")
            ws.row_dimensions[row].height=22; row+=1
        end=row-1
        ws.cell(start,1,str(host.get("host") or ""));ws.cell(start,2,str(host.get("name") or ""));ws.cell(start,3,host_ip_from_row(host))
        if end>start:
            ws.merge_cells(start_row=start,start_column=1,end_row=end,end_column=1)
            ws.merge_cells(start_row=start,start_column=2,end_row=end,end_column=2)
            ws.merge_cells(start_row=start,start_column=3,end_row=end,end_column=3)
        for col in (1,2,3):
            c=ws.cell(start,col);c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
            c.font=Font(name="Calibri",size=11,color="3B3B3B")
    for i,width in enumerate((38,38,22,16,22,44),1): ws.column_dimensions[get_column_letter(i)].width=width
    ws.auto_filter.ref=f"A1:F{max(1,row-1)}"
    output=BytesIO();wb.save(output);return output.getvalue()
