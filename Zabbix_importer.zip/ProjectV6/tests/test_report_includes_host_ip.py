"""Report export must include the Host IP column in the executive XLSX."""
import io

from openpyxl import load_workbook

import report_export
from report_export import HEADERS, build_report_workbook


def _host(**overrides):
    host = {
        "host": "srv-web-01",
        "name": "Web Server 01",
        "host_ip": "10.10.5.20",
        "ip": "10.10.5.20",
        "macros": {
            "{$DST_IP}": "8.8.8.8",
            "{$DST_PORT}": "443",
        },
        "templates": [{"name": "ICMP Ping"}],
    }
    host.update(overrides)
    return host


def _sheet(hosts):
    data = build_report_workbook(hosts)
    wb = load_workbook(io.BytesIO(data))
    ws = wb.active
    return wb, ws


def test_headers_include_host_ip():
    assert "Host IP" in HEADERS
    wb, ws = _sheet([_host()])
    header_row = [ws.cell(1, col).value for col in range(1, len(HEADERS) + 1)]
    assert header_row == list(HEADERS)
    assert header_row.index("Host IP") == 2  # third column (C)


def test_host_ip_value_written():
    wb, ws = _sheet([_host()])
    assert ws.cell(2, 3).value == "10.10.5.20"


def test_host_ip_merged_across_destination_rows():
    # Two destination blocks (INET + External) -> 2 rows for one host.
    host = _host(macros={
        "{$DST_IP_INTERNAL}": "192.168.1.10",
        "{$DST_PORT_INTERNAL}": "443",
        "{$DST_IP_EXTERNAL}": "5.6.7.8",
        "{$DST_PORT_EXTERNAL}": "80",
    })
    wb, ws = _sheet([host])
    rows = [ws.cell(r, 3).value for r in (2, 3)]
    assert rows == ["10.10.5.20", None]  # merged: only top cell keeps the value
    merged = [str(r) for r in ws.merged_cells.ranges]
    assert any(r.startswith("C2:C") for r in merged)


def test_host_ip_precedence_order():
    # interface_ip is used when host_ip absent; ip after that; host_ip_address last.
    assert report_export.host_ip_from_row(_host()) == "10.10.5.20"
    assert report_export.host_ip_from_row(_host(host_ip="")) == "10.10.5.20"
    h = _host(host_ip="", interface_ip="")
    assert report_export.host_ip_from_row(h) == "10.10.5.20"  # falls back to "ip"
    empty = report_export.host_ip_from_row({"host": "x"})
    assert empty == ""


def test_host_ip_empty_when_missing():
    wb, ws = _sheet([_host(host_ip="", interface_ip="", ip="", host_ip_address="")])
    assert (ws.cell(2, 3).value or "") == ""


def test_multiple_hosts_each_keep_own_ip():
    hosts = [
        _host(host="h1", name="n1", host_ip="1.1.1.1"),
        _host(host="h2", name="n2", host_ip="2.2.2.2"),
    ]
    wb, ws = _sheet(hosts)
    assert ws.cell(2, 3).value == "1.1.1.1"
    assert ws.cell(3, 3).value == "2.2.2.2"
