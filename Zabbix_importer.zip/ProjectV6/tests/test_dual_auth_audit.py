import unittest
from types import SimpleNamespace
from unittest.mock import patch

import audit
import server
from zabbix_api import ZabbixAPI


class DualAuthAuditTest(unittest.TestCase):
    def test_token_owner_resolves_username_from_authentication_response(self):
        api = ZabbixAPI("http://zabbix.invalid/api_jsonrpc.php", "opaque-test-token")
        api._request = unittest.mock.Mock(return_value={"username": "token-owner"})
        self.assertEqual(api.resolve_token_owner(), "token-owner")
        method, params = api._request.call_args.args[:2]
        self.assertEqual(method, "user.checkAuthentication")
        self.assertNotIn("extend", params)
        self.assertEqual(params["token"], "opaque-test-token")

    def test_login_audit_records_identity_ip_method_and_sanitized_error(self):
        with patch.object(audit, "_write", side_effect=lambda entry: entry):
            entry = audit.log_app_login_event(
                "alice", "192.0.2.9", "api_token", "failed", "bad\ncredential", "https://zabbix.invalid"
            )
        self.assertEqual(entry["event"], "app_login")
        self.assertEqual(entry["username"], "alice")
        self.assertEqual(entry["client_ip"], "192.0.2.9")
        self.assertEqual(entry["auth_method"], "api_token")
        self.assertEqual(entry["status"], "failed")
        self.assertEqual(entry["error"], "bad credential")
        self.assertNotIn("credential\n", str(entry))

    def test_client_ip_prefers_first_forwarded_address(self):
        handler = object.__new__(server.ImporterHandler)
        handler.headers = {"X-Forwarded-For": "198.51.100.7, 10.0.0.1", "X-Real-IP": "203.0.113.8"}
        handler.client_address = ("127.0.0.1", 50000)
        self.assertEqual(handler._client_ip(), "198.51.100.7")

    def test_client_ip_falls_back_to_real_ip_then_socket(self):
        handler = object.__new__(server.ImporterHandler)
        handler.headers = {"X-Real-IP": "203.0.113.8"}
        handler.client_address = ("127.0.0.1", 50000)
        self.assertEqual(handler._client_ip(), "203.0.113.8")
        handler.headers = {}
        self.assertEqual(handler._client_ip(), "127.0.0.1")


if __name__ == "__main__":
    unittest.main()
