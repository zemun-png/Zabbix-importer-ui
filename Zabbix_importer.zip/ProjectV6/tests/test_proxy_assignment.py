"""Proxy assignment tests for create_host (Zabbix 6.x vs 7.x)."""
import pytest

import zabbix_api
from zabbix_api import ZabbixAPI, ZabbixAPIError


class FakeAPI(ZabbixAPI):
    """ZabbixAPI stub that records host.create payloads."""

    def __init__(self, version="7.0.5", errors=None):
        self._version = None
        self._fixed_version = version
        self._errors = errors or {}  # extra payload -> exception
        self.calls = []

    def _api_version(self):
        v = self._fixed_version
        return tuple(int(x) for x in v.split(".")[:2]) if v else None

    def call(self, method, params=None, auth=True):
        if method == "host.create":
            self.calls.append(params)
            err = self._errors.get(id(params))
            if err is not None:
                raise err
            return {"hostids": ["1001"]}
        raise AssertionError("unexpected method %s" % method)


def err_unexpected_proxy(field):
    return ZabbixAPIError('Zabbix API error -32602: Invalid params; unexpected parameter "%s".' % field)


def err_other():
    return ZabbixAPIError("Zabbix API error -32500: Host with the same name already exists.")


def test_zabbix7_uses_proxyid():
    api = FakeAPI("7.0.5")
    hostid = api.create_host({"host": "h1", "proxyid": "9001", "proxy_hostid": "8001"})
    assert hostid == "1001"
    assert len(api.calls) == 1
    sent = api.calls[0]
    assert sent["proxyid"] == "9001"
    assert sent["monitored_by"] == 1
    assert "proxy_hostid" not in sent
    assert "proxy_groupid" not in sent


def test_zabbix7_uses_proxy_groupid():
    api = FakeAPI("7.0.19")
    api.create_host({"host": "h2", "proxy_groupid": "7"})
    sent = api.calls[0]
    assert sent["proxy_groupid"] == "7"
    assert sent["monitored_by"] == 2
    assert "proxyid" not in sent
    assert "proxy_hostid" not in sent


def test_zabbix6_uses_proxy_hostid():
    api = FakeAPI("6.0.0")
    api.create_host({"host": "h3", "proxyid": "9001", "proxy_hostid": "8001"})
    sent = api.calls[0]
    assert sent["proxy_hostid"] == "8001"
    assert "proxyid" not in sent
    assert "proxy_groupid" not in sent


def test_zabbix6_ignores_proxyid_alone():
    api = FakeAPI("6.4")
    api.create_host({"host": "h4", "proxyid": "9001"})
    sent = api.calls[0]
    assert sent["proxy_hostid"] == "9001"


def test_unexpected_proxy_param_raises_on_zabbix7():
    """STRICT: proxy assignment rejected => ZabbixAPIError, host NOT created."""
    api = FakeAPI("7.0.5")
    original = api.call

    def failing(method, params=None, auth=True):
        if method == "host.create":
            api.calls.append(params)
            raise err_unexpected_proxy("proxyid")
        return original(method, params, auth)

    api.call = failing
    with pytest.raises(ZabbixAPIError) as exc:
        api.create_host({"host": "h5", "proxyid": "9001"})
    assert "Proxy assignment was requested but rejected" in str(exc.value)
    assert "NOT created" in str(exc.value)
    assert len(api.calls) == 1  # no silent retry without proxy fields
    assert "proxyid" in api.calls[0]  # proxy field was actually attempted


def test_non_proxy_error_is_raised_not_retried():
    api = FakeAPI("7.0.5")
    original = api.call

    def failing(method, params=None, auth=True):
        if method == "host.create":
            api.calls.append(params)  # record the attempt like FakeAPI.call does
            raise err_other()
        return original(method, params, auth)

    api.call = failing
    with pytest.raises(ZabbixAPIError) as exc:
        api.create_host({"host": "h7", "proxyid": "9001"})
    assert "already exists" in str(exc.value)
    assert len(api.calls) == 1  # no blind retry


def test_proxy_param_error_detection():
    assert ZabbixAPI._proxy_param_error(err_unexpected_proxy("proxyid"))
    assert not ZabbixAPI._proxy_param_error(err_other())
    assert not ZabbixAPI._proxy_param_error(ZabbixAPIError("unexpected parameter \"tags\""))


# ---------------- Proxy edge-case tests ----------------

import pytest

class TestSanitizeProxyId:
    @pytest.mark.parametrize("raw", [0, "0", "0.0", 0.0, "  0  ", -1, "-5", "abc",
                                     None, "", "   ", "none", "None", "NULL", "null", "-", True])
    def test_invalid_values_become_none(self, raw):
        assert ZabbixAPI.sanitize_proxy_id(raw) is None

    @pytest.mark.parametrize("raw,expected", [("12", "12"), (" 34 ", "34"),
                                              ("56.0", "56"), (78, "78"),
                                              (90.0, "90"), ("0099", "99")])
    def test_valid_values_normalised(self, raw, expected):
        assert ZabbixAPI.sanitize_proxy_id(raw) == expected

def _mk(version="7.0.5"):
    return FakeAPI(version)

def test_proxyid_zero_is_dropped_zabbix7():
    api = _mk()
    api.create_host({"host": "z0", "proxyid": 0})
    assert api.calls[0] == {"host": "z0"}

def test_proxyid_zero_point_zero_is_dropped_zabbix7():
    api = _mk()
    api.create_host({"host": "z00", "proxyid": "0.0"})
    assert api.calls[0] == {"host": "z00"}

def test_proxyid_empty_string_is_dropped_zabbix7():
    api = _mk()
    api.create_host({"host": "z1", "proxyid": "   "})
    assert api.calls[0] == {"host": "z1"}

def test_proxyid_null_is_dropped_zabbix7():
    api = _mk()
    api.create_host({"host": "z2", "proxyid": None})
    assert api.calls[0] == {"host": "z2"}

def test_proxy_groupid_zero_is_dropped_zabbix7():
    api = _mk()
    api.create_host({"host": "z3", "proxy_groupid": "0"})
    assert api.calls[0] == {"host": "z3"}

def test_both_proxyid_and_proxy_groupid_sends_only_group_zabbix7():
    api = _mk()
    api.create_host({"host": "z4", "proxyid": "9001", "proxy_groupid": "7"})
    sent = api.calls[0]
    assert sent["proxy_groupid"] == "7"
    assert sent["monitored_by"] == 2
    assert "proxyid" not in sent
    assert "proxy_hostid" not in sent

def test_both_proxyid_and_proxy_hostid_zabbix6_sends_single_field():
    api = _mk("6.0.0")
    api.create_host({"host": "z5", "proxyid": "9001", "proxy_hostid": "8001"})
    sent = api.calls[0]
    assert sent["proxy_hostid"] == "8001"
    assert "proxyid" not in sent

def test_value_must_be_zero_error_raises_on_zabbix7():
    """STRICT: proxyid rejected on Zabbix 7 => ZabbixAPIError, no unassigned host."""
    api = _mk("7.0.5")
    original = api.call
    attempts = {"n": 0}

    def failing(method, params=None, auth=True):
        if method == "host.create":
            attempts["n"] += 1
            api.calls.append(params)
            raise ZabbixAPIError("Zabbix API error -32602: Invalid params. Value must be 0.")
        return original(method, params, auth)

    api.call = failing
    with pytest.raises(ZabbixAPIError) as exc:
        api.create_host({"host": "z6", "proxyid": "9001"})
    assert "Proxy assignment was requested but rejected" in str(exc.value)
    assert attempts["n"] == 1
    assert "proxyid" in api.calls[0]


def test_value_must_be_zero_error_raises_on_zabbix6():
    """STRICT: proxy_hostid rejected on Zabbix 6 => ZabbixAPIError."""
    api = _mk("6.0.0")
    original = api.call
    attempts = {"n": 0}

    def failing(method, params=None, auth=True):
        if method == "host.create":
            attempts["n"] += 1
            api.calls.append(params)
            raise ZabbixAPIError("Zabbix API error -32602: proxy_hostid: value must be zero.")
        return original(method, params, auth)

    api.call = failing
    with pytest.raises(ZabbixAPIError) as exc:
        api.create_host({"host": "z7", "proxy_hostid": "8001"})
    assert "Proxy assignment was requested but rejected" in str(exc.value)
    assert attempts["n"] == 1
    assert "proxy_hostid" in api.calls[0]

def test_all_zero_fields_send_no_proxy_on_zabbix6():
    api = _mk("6.0.0")
    api.create_host({"host": "z8", "proxyid": "0", "proxy_hostid": None})
    assert api.calls[0] == {"host": "z8"}
