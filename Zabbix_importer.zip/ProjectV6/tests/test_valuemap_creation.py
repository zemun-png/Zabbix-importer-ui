import unittest
from unittest.mock import Mock

from zabbix_api import ZabbixAPI, ZabbixAPIError


class ValueMapCreationTest(unittest.TestCase):
    def test_import_host_creates_host_without_valuemaps_then_creates_map(self):
        api = ZabbixAPI(url="http://zabbix.invalid/api_jsonrpc.php")
        api.authenticated = True
        api.call = Mock(side_effect=[
            "7.0.0",
            {"hostids": ["42001"]},
            {"valuemapids": ["73001"]},
        ])
        payload = {
            "host": "test-host",
            "interfaces": [{"type": 1, "ip": "192.0.2.10", "port": "10050", "main": 1, "useip": 1, "dns": "", "details": {}}],
            "groups": [{"groupid": "2"}],
            "valuemaps": [{
                "name": "Operating system",
                "mappings": [
                    {"type": 0, "value": "1", "newvalue": "Linux"},
                    {"type": 2, "value": "2", "newvalue": "Windows"},
                ],
            }],
        }

        hostid = api.import_host(payload)

        self.assertEqual(hostid, "42001")
        calls = api.call.call_args_list
        host_calls = [call for call in calls if call.args[0] == "host.create"]
        valuemap_calls = [call for call in calls if call.args[0] == "valuemap.create"]
        self.assertEqual(len(host_calls), 1)
        self.assertNotIn("valuemaps", host_calls[0].args[1])
        self.assertEqual(len(valuemap_calls), 1)
        self.assertEqual(valuemap_calls[0].args[1], {
            "hostid": "42001",
            "name": "Operating system",
            "mappings": [
                {"type": 0, "value": "1", "newvalue": "Linux"},
                {"type": 2, "value": "2", "newvalue": "Windows"},
            ],
        })



    def test_import_host_creates_second_map_only_when_first_fails(self):
        api = ZabbixAPI(url="http://zabbix.invalid/api_jsonrpc.php")
        api.authenticated = True
        api.call = Mock(side_effect=[
            "7.0.0",
            {"hostids": ["42002"]},
            ZabbixAPIError("Zabbix API error -32602: Value map with name \"Operating system\" already exists."),
            {"valuemapids": ["73002"]},
        ])
        payload = {
            "host": "test-host",
            "valuemaps": [
                {"name": "Operating system", "mappings": [{"type": 0, "value": "1", "newvalue": "Linux"}]},
                {"name": "Other", "mappings": [{"type": 0, "value": "1", "newvalue": "Other"}]},
            ],
        }
        with self.assertRaises(ZabbixAPIError) as ctx:
            api.import_host(payload)
        self.assertIn('Zabbix API error -32602', str(ctx.exception))
        self.assertIn('already exists', str(ctx.exception))
        self.assertEqual([c.args[0] for c in api.call.call_args_list if c.args[0] == "valuemap.create"],
                         ["valuemap.create"])

    def test_import_host_rejects_incomplete_mapping(self):
        api = ZabbixAPI(url="http://zabbix.invalid/api_jsonrpc.php")
        api.authenticated = True
        api.call = Mock(side_effect=["7.0.0", {"hostids": ["42003"]}])
        payload = {
            "host": "test-host",
            "valuemaps": [{"name": "Operating system", "mappings": [{"type": 0, "value": "1"}]}],
        }
        with self.assertRaises(ZabbixAPIError) as ctx:
            api.import_host(payload)
        self.assertIn("incomplete mapping", str(ctx.exception))
        valuemap_calls = [c for c in api.call.call_args_list if c.args[0] == "valuemap.create"]
        self.assertEqual(valuemap_calls, [])


if __name__ == "__main__":
    unittest.main()
