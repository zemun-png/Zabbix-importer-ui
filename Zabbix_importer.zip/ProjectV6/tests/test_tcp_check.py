import json
import threading
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import Mock, patch

from http.server import ThreadingHTTPServer
from zabbix_api import ZabbixAPI, ZabbixAPIError, TCP_TEMPLATE_NAMES
import server as app_server


class TcpCheckAPITest(unittest.TestCase):
    def api(self):
        api = ZabbixAPI(url="http://zabbix.invalid/api_jsonrpc.php")
        api.authenticated = True
        return api

    def test_template_lookup_is_allowlisted(self):
        api = self.api()
        api.call = Mock(return_value=[{"name": TCP_TEMPLATE_NAMES[0], "templateid": "10"},
                                      {"name": TCP_TEMPLATE_NAMES[1], "templateid": "11"},
                                      {"name": "Unrelated template", "templateid": "12"}])
        self.assertEqual(api._tcp_templates(), {TCP_TEMPLATE_NAMES[0]: "10", TCP_TEMPLATE_NAMES[1]: "11"})
        method, params = api.call.call_args.args
        self.assertEqual(method, "template.get")
        self.assertEqual(set(params["filter"]["name"]), set(TCP_TEMPLATE_NAMES))

    def test_host_search_retrieval_includes_interface_ip_for_matching(self):
        api = self.api()
        api.call = Mock(side_effect=[
            [{"name": TCP_TEMPLATE_NAMES[0], "templateid": "10"}],
            [{"hostid": "42", "host": "node-a", "name": "Node Alpha", "status": "0",
              "interfaces": [{"ip": "192.0.2.44", "dns": "node-a.example", "main": "1"}]}],
        ])
        hosts = api.tcp_hosts()
        self.assertEqual(len(hosts), 1)
        self.assertEqual(hosts[0]["hostid"], "42")
        # The endpoint returns interfaces so the UI's name/IP search can match either.
        self.assertIn("192.0.2.44", [i["ip"] for i in hosts[0]["interfaces"]])
        call = api.call.call_args_list[1]
        self.assertEqual(call.args[0], "host.get")
        self.assertEqual(call.args[1]["templateids"], ["10"])
        self.assertIn("selectInterfaces", call.args[1])

    def test_tcp_host_details_retrieval(self):
        api = self.api()
        def call(method, params):
            if method == "template.get": return [{"name": TCP_TEMPLATE_NAMES[0], "templateid": "10"}]
            if method == "host.get" and params.get("hostids") == ["42"]:
                return [{"hostid": "42", "host": "node", "name": "Node", "status": "0",
                         "interfaces": [{"ip": "198.51.100.2"}],
                         "parentTemplates": [{"templateid": "10", "name": TCP_TEMPLATE_NAMES[0]}]}]
            if method == "usermacro.get": return []
            self.fail("Unexpected API request: " + method)
        api.call = Mock(side_effect=call)
        detail = api.tcp_host_details("42")
        self.assertEqual(detail["hostid"], "42")
        self.assertEqual(detail["interfaces"][0]["ip"], "198.51.100.2")

    def test_hosts_are_deduplicated_across_templates(self):
        api = self.api()
        all_templates = [{"name": n, "templateid": str(10 + i)} for i, n in enumerate(TCP_TEMPLATE_NAMES)]
        host_rows = [{"hostid": "1", "host": "node-a", "name": "Node A", "status": "0"}] * len(all_templates)
        api.call = Mock(side_effect=[all_templates] + [list(host_rows) for _ in all_templates])
        self.assertEqual(len(TCP_TEMPLATE_NAMES), 4)
        hosts = api.tcp_hosts()
        self.assertEqual(len(hosts), 1)
        self.assertEqual(set(hosts[0]["tcp_templates"]), set(TCP_TEMPLATE_NAMES))

    def test_multiple_macro_pairs_create_and_update(self):
        api = self.api()
        api.call = Mock(side_effect=[
            [{"hostmacroid": "5", "macro": "{$DST_IP}", "value": "old"}],
            {"hostmacroid": "5"}, {"hostmacroids": ["7"]}, {"hostmacroids": ["8"]},
        ])
        values = {"{$DST_IP}": "192.0.2.1,192.0.2.1", "{$DST_PORT}": "80,443", "{$DST_IP_EXTERNAL}": "203.0.113.4"}
        result = api.tcp_update_macros("42", values)
        self.assertEqual([x["action"] for x in result], ["updated", "created", "created"])
        calls = api.call.call_args_list
        self.assertEqual([c.args[0] for c in calls], ["usermacro.get", "usermacro.update", "usermacro.create", "usermacro.create"])
        self.assertEqual(calls[1].args[1], {"hostmacroid": "5", "value": "192.0.2.1,192.0.2.1"})
        self.assertEqual(calls[2].args[1], {"hostid": "42", "macro": "{$DST_PORT}", "value": "80,443"})

    def test_empty_string_clears_existing_macro_and_can_create_empty(self):
        api = self.api()
        def call(method, params):
            if method == "usermacro.get":
                return [{"hostmacroid": "9", "macro": "{$DST_IP}", "value": "old"}]
            if method == "usermacro.delete":
                return {"hostmacroids": ["9"]}
            self.fail("Unexpected API request: " + method)
        api.call = Mock(side_effect=call)
        result = api.tcp_update_macros("42", {"{$DST_IP}": "", "{$DST_PORT}": ""})
        self.assertEqual([r["action"] for r in result], ["deleted", "skipped"])
        delete_call = api.call.call_args_list[1]
        self.assertEqual(delete_call.args[0], "usermacro.delete")
        self.assertEqual(delete_call.args[1], ["9"])
        # Non-existing macro with empty string must not be created.
        self.assertEqual([c.args[0] for c in api.call.call_args_list],
                         ["usermacro.get", "usermacro.delete"])

    def test_empty_string_on_existing_macro_triggers_usermacro_delete(self):
        api = self.api()
        def call(method, params):
            if method == "usermacro.get":
                return [{"hostmacroid": "23", "macro": "{$DST_IP}"}]
            if method == "usermacro.delete":
                return {"hostmacroids": ["23"]}
            self.fail("Unexpected API request: " + method)
        api.call = Mock(side_effect=call)
        result = api.tcp_update_macros("42", {"{$DST_IP}": ""})
        self.assertEqual(result, [{"macro": "{$DST_IP}", "action": "deleted"}])
        self.assertEqual(api.call.call_args_list[1].args, ("usermacro.delete", ["23"]))

    def test_empty_string_on_nonexisting_macro_does_not_call_usermacro_create(self):
        api = self.api()
        api.call = Mock(return_value=[])
        result = api.tcp_update_macros("42", {"{$DST_IP}": "", "{$DST_PORT}": ""})
        self.assertEqual(result, [{"macro": "{$DST_IP}", "action": "skipped"},
                                  {"macro": "{$DST_PORT}", "action": "skipped"}])
        methods = [c.args[0] for c in api.call.call_args_list]
        self.assertEqual(methods, ["usermacro.get"])
        self.assertNotIn("usermacro.create", methods)

    def test_macro_updates_reject_invalid_payloads_with_clear_errors(self):
        api = self.api()
        for hostid, values, message in [("x", {"{$DST_IP}": "a"}, "host ID"),
                                        ("42", {}, "No macro"),
                                        ("42", {"{$BAD}": "x"}, "not allowed"),
                                        ("42", {"{$DST_IP}": None}, "scalar value")]:
            with self.subTest(values=values), self.assertRaisesRegex(ZabbixAPIError, message):
                api.tcp_update_macros(hostid, values)
        api.call = Mock(return_value=[{"hostmacroid": None, "macro": "{$DST_IP}"}])
        with self.assertRaisesRegex(ZabbixAPIError, "no host macro ID"):
            api.tcp_update_macros("42", {"{$DST_IP}": "v"})

    def test_multi_port_expansion_uses_parallel_repeated_ip_arrays(self):
        # Mirrors tcp-check.js: split comma-separated values into parallel LLD arrays.
        pairs = [("10.0.0.8", p) for p in ("80", "443", "8080")] + [("10.0.0.9", "22")]
        self.assertEqual(",".join(ip for ip, _ in pairs), "10.0.0.8,10.0.0.8,10.0.0.8,10.0.0.9")
        self.assertEqual(",".join(port for _, port in pairs), "80,443,8080,22")


class TcpUpdateEndpointTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), app_server.ImporterHandler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = "http://127.0.0.1:%s/api/tcp_update_macros" % cls.httpd.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown(); cls.httpd.server_close(); cls.thread.join(timeout=2)

    def request(self, body):
        req = Request(self.url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(req, timeout=3) as response: return response.status, json.loads(response.read().decode())
        except HTTPError as exc:
            return exc.code, json.loads(exc.read().decode())

    def test_endpoint_returns_200_json_for_mocked_zabbix_api(self):
        fake = Mock()
        fake.tcp_update_macros.return_value = [{"macro": "{$DST_IP}", "action": "updated"}, {"macro": "{$DST_PORT}", "action": "created"}]
        with patch.object(app_server, "get_api", return_value=(fake, "tester")):
            status, payload = self.request({"hostid": "42", "macros": {"{$DST_IP}": "192.0.2.1", "{$DST_PORT}": "443"}})
        self.assertEqual(status, 200)
        self.assertEqual(payload["results"], fake.tcp_update_macros.return_value)
        self.assertIn("diff", payload)

    def test_endpoint_audits_tcp_macro_update_on_success(self):
        fake = Mock()
        fake.tcp_host_details.side_effect = [
            {"macros": {}},  # before update: empty macros
            {"macros": {"{$DST_IP}": {"value": "192.0.2.1"},
                        "{$DST_PORT}": {"value": "443"}}}  # after update
        ]
        fake.tcp_update_macros.return_value = [{"macro": "{$DST_IP}", "action": "created"}]
        with patch.object(app_server, "get_api", return_value=(fake, "tester")), \
             patch.object(app_server, "log_tcp_macro_event") as audit_mock:
            status, payload = self.request({"hostid": "42", "hostname": "node-a",
                                            "macros": {"{$DST_IP}": "192.0.2.1"}})
        self.assertEqual(status, 200)
        audit_mock.assert_called_once()
        args = audit_mock.call_args
        self.assertEqual(args.args[0], "tester")
        self.assertEqual(args.args[1], "42")
        self.assertEqual(args.args[3]["added"], [{"ip": "192.0.2.1", "port": "443"}])
        fake.tcp_update_macros.assert_called_once_with("42", {"{$DST_IP}": "192.0.2.1"})

    def test_endpoint_returns_clear_json_error_without_500(self):
        with patch.object(app_server, "get_api", side_effect=ZabbixAPIError("Not connected. Authenticate first.")):
            status, payload = self.request({"hostid": "42", "macros": {"{$DST_IP}": "x"}})
        self.assertEqual(status, 400)
        self.assertEqual(payload, {"error": "Not connected. Authenticate first."})

    def test_endpoint_surfaces_macro_not_found_or_validation_error_as_json(self):
        fake = Mock()
        fake.tcp_update_macros.side_effect = ZabbixAPIError("A valid host ID is required")
        with patch.object(app_server, "get_api", return_value=(fake, "tester")):
            status, payload = self.request({"hostid": "bad", "macros": {"{$DST_IP}": "x"}})
        self.assertEqual(status, 400)
        self.assertEqual(payload["error"], "A valid host ID is required")


if __name__ == "__main__":
    unittest.main()


# ---------------------------------------------------------------------------
# Unit tests for tcp-check.js logic (run via node) and index.html UI elements.
# ---------------------------------------------------------------------------

import os
import re
import subprocess
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TCP_JS = os.path.join(PROJECT_ROOT, "static", "js", "tcp-check.js")
INDEX_HTML = os.path.join(PROJECT_ROOT, "index.html")

# The harness relies on the TcpCheckInternals object that tcp-check.js already
# sets on window: no brittle unwrapping of the IIFE closure, no appending
# exports after the closure. We just eval the file and re-export that object.
def _load_tcp_js():
    """Load tcp-check.js in node with minimal DOM stubs and return its internals.

    NOTE: functions cannot survive JSON.stringify (they are silently dropped),
    so we return real Python callables backed by a node subprocess per call.
    """
    stub = """
const fs = require('fs');
const _elements = {};
function makeEl(id) {
  return { id, value: '', innerHTML: '', textContent: '', className: '', dataset: {},
           disabled: false, style: {},
           addEventListener() {}, removeEventListener() {},
           querySelectorAll() { return []; }, querySelector() { return null; },
           closest() { return null; }, focus() {}, classList: { add(){}, remove(){}, toggle(){} } };
}
globalThis.document = {
  getElementById(id) { if (!_elements[id]) _elements[id] = makeEl(id); return _elements[id]; },
  querySelectorAll() { return []; }, querySelector() { return null; },
  addEventListener() {}, removeEventListener() {},
  createElement() { return makeEl('_tmp'); },
  body: makeEl('body'), documentElement: makeEl('html'),
};
globalThis.window = { addEventListener() {}, confirm() { return true; }, location: { href: '' } };
window.api = { get: () => {}, post: () => {} };
URL.createObjectURL = () => '';
Blob = class {};
globalThis.localStorage = { getItem() { return null; }, setItem() {}, removeItem() {} };

const script = fs.readFileSync(__TCP_JS_PATH__, 'utf8');
eval(script);

const internals = globalThis.window.TcpCheckInternals;
if (!internals) throw new Error('tcp-check.js did not set window.TcpCheckInternals');
internals.renderHostsForTest = function (hosts, query, filter) {
  internals.state.hosts = hosts || [];
  const searchEl = document.getElementById('tcpHostSearch');
  const filterEl = document.getElementById('tcpTemplateFilter');
  if (searchEl) searchEl.value = query || '';
  if (filterEl) filterEl.value = filter || '';
  internals.renderHosts();
  return document.getElementById('tcpHostList').innerHTML;
};
internals.setStateForTest = function (patch) { Object.assign(internals.state, patch || {}); };
// Manifest of the exports: JSON.stringify would drop every function, so we
// report names + types instead and invoke functions through the driver below.
console.log(JSON.stringify(Object.fromEntries(
  Object.entries(internals).map(([k, v]) => [k, typeof v])
)));
module.exports = internals;
"""
    tmp = os.path.join(os.environ.get("TMPDIR", "/tmp"), "tcp_check_under_test.js")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(stub.replace("__TCP_JS_PATH__", json.dumps(TCP_JS)))
    out = subprocess.run(["node", tmp], capture_output=True, text=True, timeout=30)
    if out.returncode != 0:
        raise AssertionError("node failed to load tcp-check.js:\n" + out.stderr)
    manifest = json.loads(out.stdout.strip().splitlines()[-1])
    if not manifest:
        raise AssertionError("node loaded tcp-check.js but TcpCheckInternals is empty")

    driver = (
        "const m = require(process.argv[1]);"
        "const fn = m[process.argv[2]];"
        "if (typeof fn !== 'function') throw new Error('not a function: ' + process.argv[2]);"
        "const args = JSON.parse(process.argv[3] || '[]');"
        "process.stdout.write(JSON.stringify(fn(...args)));"
    )

    class _NodeFunction:
        """Callable proxy that runs the named export in a fresh node process."""
        def __init__(self, name):
            self.name = name
        def __call__(self, *args):
            run = subprocess.run(["node", "-e", driver, tmp, self.name, json.dumps(list(args))],
                                 capture_output=True, text=True, timeout=30)
            if run.returncode != 0:
                raise AssertionError("node call %s failed:\n%s" % (self.name, run.stderr))
            lines = [line.strip() for line in run.stdout.strip().splitlines() if line.strip()]
            return json.loads(lines[-1])

    class _NodeInternals(dict):
        def __getitem__(self, key):
            if manifest.get(key) == "function":
                return _NodeFunction(key)
            return super().__getitem__(key)
        def __contains__(self, key):
            return key in manifest or super().__contains__(key)

    return _NodeInternals({k: ("__function__" if t == "function" else None)
                           for k, t in manifest.items()})

class TcpCheckJsLogicTest(unittest.TestCase):
    """Mirrors tcp-check.js behaviour by executing the real file in node."""

    @classmethod
    def setUpClass(cls):
        cls.js = _load_tcp_js()

    # ---- Cartesian bulk target generation -------------------------------
    def test_bulk_targets_are_cartesian_product_of_ips_and_ports(self):
        result = self.js["parseBulkTargets"]("10.0.0.1, 10.0.0.2", "80,443")
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["targets"], [
            {"ip": "10.0.0.1", "port": "80", "valid": True},
            {"ip": "10.0.0.1", "port": "443", "valid": True},
            {"ip": "10.0.0.2", "port": "80", "valid": True},
            {"ip": "10.0.0.2", "port": "443", "valid": True},
        ])
        self.assertEqual(len(result["targets"]), 2 * 2)

    def test_bulk_targets_flag_invalid_entries_but_keep_pairs(self):
        result = self.js["parseBulkTargets"]("10.0.0.1, ", "80,99999,x")
        # 1 IP x 3 port slots = 3 pairs, ports out of range / empty flagged invalid.
        self.assertEqual(len(result["targets"]), 3)
        self.assertFalse(result["targets"][1]["valid"])
        self.assertFalse(result["targets"][2]["valid"])
        joined = " ".join(result["errors"]).lower()
        self.assertIn("port", joined)

    def test_bulk_targets_requires_input(self):
        result = self.js["parseBulkTargets"]("", "")
        self.assertTrue(any("IP" in e or "ip" in e for e in result["errors"]))
        self.assertTrue(any("port" in e.lower() for e in result["errors"]))

    # ---- Deduplication ---------------------------------------------------
    def test_dedupe_targets_merges_duplicate_ips_and_ports(self):
        targets = [{"ip": "10.0.0.1", "port": "80"}, {"ip": "10.0.0.1", "port": "80"},
                   {"ip": "10.0.0.1", "port": "443"}, {"ip": " 10.0.0.1 ", "port": "443"},
                   {"ip": "10.0.0.2", "port": "22"}]
        blocks = self.js["dedupeTargets"](targets)
        self.assertEqual([b["ip"] for b in blocks], ["10.0.0.1", "10.0.0.2"])
        self.assertEqual(blocks[0]["ports"], ["80", "443"])
        self.assertEqual(blocks[1]["ports"], ["22"])
        self.assertTrue(all(b["isNew"] for b in blocks))

    def test_dedupe_targets_skips_blank_and_invalid_ports(self):
        blocks = self.js["dedupeTargets"]([{"ip": "10.0.0.1", "port": "0"},
                                           {"ip": "", "port": "80"}])
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0]["ports"], [])

    def test_serialize_blocks_expands_back_to_parallel_arrays(self):
        blocks = self.js["dedupeTargets"]([{"ip": "10.0.0.1", "port": "80"},
                                           {"ip": "10.0.0.1", "port": "443"},
                                           {"ip": "10.0.0.2", "port": "22"}])
        out = self.js["serializeBlocks"](blocks)
        self.assertEqual(out, {"ips": "10.0.0.1,10.0.0.1,10.0.0.2",
                               "ports": "80,443,22", "count": 3})

    # ---- Host list search by hostname / IP --------------------------------
    def test_host_list_search_matches_hostname(self):
        hosts = [{"hostid": "1", "host": "node-a", "name": "Node Alpha", "status": "0",
                  "tcp_templates": ["Z-TCP Connection Check - Zabbix Agent-Active"],
                  "interfaces": [{"ip": "192.0.2.10", "dns": "node-a.example"}]}]
        html = self.js["renderHostsForTest"](hosts, "alpha")
        self.assertIn("Node Alpha", html)
        self.assertNotIn("No matching TCP hosts", html)

    def test_host_list_search_matches_interface_ip(self):
        hosts = [{"hostid": "1", "host": "node-a", "name": "Node Alpha", "status": "0",
                  "tcp_templates": [], "interfaces": [{"ip": "192.0.2.10", "dns": ""}]}]
        html = self.js["renderHostsForTest"](hosts, "192.0.2.10")
        self.assertIn("node-a", html)
        # and a non-matching query yields the empty-state message
        html2 = self.js["renderHostsForTest"](hosts, "203.0.113.99")
        self.assertIn("No matching TCP hosts", html2)

    def test_host_list_search_matches_macro_target_ip(self):
        hosts = [{"hostid": "2", "host": "node-b", "name": "Node B", "status": "0",
                  "tcp_templates": [],
                  "interfaces": [],
                  "macros": {"{$DST_IP}": {"value": "198.51.100.7,198.51.100.8"}}}]
        html = self.js["renderHostsForTest"](hosts, "198.51.100.8")
        self.assertIn("node-b", html)

    # ---- CSV report -------------------------------------------------------
    def test_host_report_csv_structure_and_escaping(self):
        hosts = [{"hostid": "1", "host": 'node-"x"', "name": "Node X", "status": "0",
                  "tcp_templates": ["Z-TCP Connection Check - Zabbix Agent-Active"],
                  "interfaces": [{"ip": "192.0.2.5", "dns": "node-x.example"}],
                  "macros": {"{$DST_IP}": {"value": "10.0.0.1"},
                             "{$DST_PORT}": {"value": "80,443"}}}]
        csv_text = self.js["buildHostReportCsv"](hosts)
        self.assertTrue(csv_text.startswith("\ufeff"))  # UTF-8 BOM for Excel
        lines = csv_text.replace("\ufeff", "").split("\r\n")
        self.assertEqual(lines[0], '"Hostname","Visible Name","Scope","Target IP","Monitored Ports"')
        self.assertEqual(len(lines), 3)  # header + 2 rows (one per port)
        self.assertIn('"node-""x"""', lines[1])
        self.assertIn('"General"', lines[1])
        self.assertIn('"10.0.0.1"', lines[1])
        self.assertIn('"80"', lines[1])
        self.assertIn('"443"', lines[2])

    def test_host_report_csv_is_empty_safe(self):
        csv_text = self.js["buildHostReportCsv"]([])
        lines = csv_text.replace("\ufeff", "").split("\r\n")
        self.assertEqual(len(lines), 1)
        self.assertEqual(lines[0], '"Hostname","Visible Name","Scope","Target IP","Monitored Ports"')

    def test_host_report_csv_inext_host_uses_internal_external_scopes(self):
        hosts = [{"hostid": "3", "host": "node-c", "name": "Node C", "status": "0",
                  "tcp_templates": ["Z-TCP Connection Check - Zabbix Agent-Active-INEXT"],
                  "macros": {"{$DST_IP_INTERNAL}": {"value": "172.16.0.1"},
                             "{$DST_PORT_INTERNAL}": {"value": "8080"},
                             "{$DST_IP_EXTERNAL}": {"value": "203.0.113.9"},
                             "{$DST_PORT_EXTERNAL}": {"value": "443"}}}]
        lines = self.js["buildHostReportCsv"](hosts).replace("\ufeff", "").split("\r\n")
        self.assertEqual(len(lines), 3)
        self.assertIn('"Internal"', lines[1])
        self.assertIn('"172.16.0.1"', lines[1])
        self.assertIn('"External"', lines[2])
        self.assertIn('"203.0.113.9"', lines[2])

    # ---- detectHostMode -----------------------------------------------------
    def test_detect_host_mode_inext_vs_agent(self):
        # INEXT template name -> inext
        self.assertEqual(self.js["detectHostMode"](
            {"tcp_templates": ["Z-TCP Connection Check - Zabbix Agent-Active-INEXT"]}), "inext")
        # Agent template (no INEXT) -> agent
        self.assertEqual(self.js["detectHostMode"](
            {"tcp_templates": ["Z-TCP Connection Check - Zabbix Agent-Active"]}), "agent")
        self.assertEqual(self.js["detectHostMode"](
            {"tcp_templates": ["Z-TCP Connection Check - Zabbix Agent"]}), "agent")
        # INEXT macros only -> inext
        self.assertEqual(self.js["detectHostMode"](
            {"tcp_templates": [],
             "macros": {"{$DST_IP_INTERNAL}": {"value": "10.0.0.1"}}}), "inext")
        # Agent macros only -> agent
        self.assertEqual(self.js["detectHostMode"](
            {"tcp_templates": [], "macros": {"{$DST_IP}": {"value": "10.0.0.1"}}}), "agent")

class IndexHtmlTcpUiTest(unittest.TestCase):
    """All TCP tab UI elements used by tcp-check.js must exist in index.html."""

    @classmethod
    def setUpClass(cls):
        cls.html = open(INDEX_HTML, encoding="utf-8").read()

    def ids(self):
        return set(re.findall(r'id="([^"]+)"', self.html))

    def test_tcp_element_ids_present(self):
        required = ["tcpHostList", "tcpHostSearch", "tcpTemplateFilter",
                    "tcpTemplateFilterBadge", "tcpHostDetails", "tcpPairEditor",
                    "tcpMessage", "tcpRefreshBtn", "tcpSaveBtn", "tcpExportReportBtn",
                    "tabTcpCheck"]
        missing = [i for i in required if i not in self.ids()]
        self.assertEqual(missing, [])

    def test_tcp_tab_and_scripts_wired(self):
        self.assertIn('id="tabTcpCheck"', self.html)
        self.assertIn("static/js/tcp-check.js", self.html)
        self.assertIn("static/js/app.js", self.html)

    def test_tcp_css_classes_referenced_by_js_exist_in_stylesheet(self):
        css = open(os.path.join(PROJECT_ROOT, "static", "css", "style.css"), encoding="utf-8").read()
        for cls in ["tcp-host-item", "tcp-bulk-ips", "tcp-bulk-ports", "tcp-bulk-add",
                    "tcp-bulk-error", "tcp-block-list", "tcp-preview", "tcp-template-badge"]:
            self.assertIn(cls, css, "missing CSS class: " + cls)
