"""Central configuration for the Zabbix Importer project."""

# ---------------------------------------------------------------------------
# Zabbix server connection
# ---------------------------------------------------------------------------
ZABBIX_URL = "http://localhost/zabbix/api_jsonrpc.php"
ZABBIX_TOKEN = ""
ZABBIX_USER = "Admin"
ZABBIX_PASSWORD = "zabbix"

# When True the login token is cached in memory and reused for every call.
ZABBIX_VERIFY_SSL = False

# ---------------------------------------------------------------------------
# Web UI server
# ---------------------------------------------------------------------------
WEB_HOST = "0.0.0.0"
WEB_PORT = 8988
WEB_DEBUG = False

# Audit log file (created next to server.py in logs/) - see audit.py
AUDIT_LOG_NAME = "zabbix_import_audit.log"

# Where the static files live (relative to the project root directory).
STATIC_DIR = "static"

# Single-host defaults
DEFAULT_TAG_VALUE = ""

# ---------------------------------------------------------------------------
# Import behaviour
# ---------------------------------------------------------------------------
DEFAULT_SNMP_COMMUNITY = "{$SNMP_COMMUNITY}"
DEFAULT_AGENT_PORT = "10050"
DEFAULT_SNMP_PORT = "161"
DEFAULT_IPMI_PORT = "623"
DEFAULT_JMX_PORT = "12345"

# Timeouts (seconds)
API_TIMEOUT = 30
SERVER_REQUEST_TIMEOUT = 30
