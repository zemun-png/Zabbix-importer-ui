"""Thread-safe UTF-8 JSON-lines audit log (host imports, TCP macro changes, app logins)."""
import datetime,json,os,threading
import config
_LOCK=threading.Lock();LOG_DIR=os.path.join(os.path.dirname(os.path.abspath(__file__)),"logs")
LOG_PATH=os.path.join(LOG_DIR,getattr(config,"AUDIT_LOG_NAME","zabbix_import_audit.log"))

# Values that must never appear in audit records.
FORBIDDEN_KEYS=("password","secret","token","authorization","session_id","session_token")

def _write(entry):
    with _LOCK:
        os.makedirs(LOG_DIR,exist_ok=True)
        with open(LOG_PATH,"a",encoding="utf-8") as f:f.write(json.dumps(entry,ensure_ascii=False)+"\n")
    return entry

def _stamp():
    return datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat(timespec="seconds")

def log_host_event(username,host,ip,mode,status,error="",hostid=None):
    entry={"timestamp":_stamp(),"username":username or "(unknown)","hostname":host,"ip":ip,"mode":mode,"status":status}
    if hostid is not None:entry["hostid"]=hostid
    if error:entry["error"]=_safe_text(error)
    return _write(entry)

def log_tcp_macro_event(username,hostid,hostname="",diff=None,status="success",error="",client_ip=""):
    """Audit log entry for TCP macro updates, including the added/removed/modified diff."""
    entry={"timestamp":_stamp(),
           "username":username or "(unknown)","event":"tcp_macros","hostid":str(hostid),"hostname":hostname or "",
           "client_ip":client_ip or "(unknown)",
           "mode":"tcp_macros","status":status,
           "diff":diff or {"added":[],"removed":[],"modified":[]}}
    if error:entry["error"]=_safe_text(error)
    return _write(entry)

def _safe_text(value, limit=300):
    """Truncate and stringify an error/URL so audit lines stay short and safe."""
    if value is None:
        return ""
    text = str(value).replace("\r", " ").replace("\n", " ").replace("\t", " ")
    text = " ".join(text.split())
    return text[:max(0, int(limit))]

def log_app_login_event(username,client_ip,auth_method,status,error="",zabbix_url=""):
    """Audit record for a connection/login attempt against the importer UI.

    Records who connected from which address and how. NEVER include the
    password, API token, Authorization header value or session id here:
    only a short, safe error description is stored.
    """
    if auth_method not in ("api_token", "username_password", "token", "username_password"):
        auth_method="unknown"
    entry={"timestamp":_stamp(),
           "event":"app_login",
           "username":username or "(unknown)",
           "client_ip":client_ip or "(unknown)",
           "auth_method":auth_method,
           "status":status if status in ("success","failed") else "failed"}
    if zabbix_url:entry["zabbix_url"]=_safe_text(zabbix_url, 200)
    if error:entry["error"]=_safe_text(error)
    return _write(entry)
