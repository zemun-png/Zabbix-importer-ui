"""Small Zabbix JSON-RPC client supporting API tokens and user/password sessions."""
import json
import socket
import ssl
import urllib.error
import urllib.request

import config


class ZabbixAPIError(Exception):
    """Zabbix API or transport error."""




TCP_TEMPLATE_NAMES = (
    "Z-TCP Connection Check - Zabbix Agent-Active",
    "Z-TCP Connection Check - Zabbix Agent-Active-INEXT",
    "Z-TCP Connection Check - Zabbix Agent",
    "Z-TCP Connection Check - Zabbix Agent-INEXT",
)
TCP_MACROS = {
    "{$DST_IP}", "{$DST_PORT}", "{$DST_IP_EXTERNAL}", "{$DST_PORT_EXTERNAL}",
    "{$DST_IP_INTERNAL}", "{$DST_PORT_INTERNAL}", "{$PORT_RES_TRSH}",
}

class ZabbixAPI:
    def __init__(self, url=None, api_token=None, user=None, password=None, verify_ssl=None, timeout=None):
        self.url = (url or config.ZABBIX_URL).strip()
        self.api_token = api_token or ""
        self.user = user or ""
        self.password = password or ""
        self.verify_ssl = config.ZABBIX_VERIFY_SSL if verify_ssl is None else verify_ssl
        self.timeout = timeout or config.API_TIMEOUT
        self._id = 0
        self.authenticated = False
        self._version = None

    def _request(self, method, params=None, auth=True):
        self._id += 1
        payload = {"jsonrpc": "2.0", "method": method, "params": params if params is not None else {}, "id": self._id}
        headers = {"Content-Type": "application/json-rpc", "User-Agent": "zabbix-importer/1.0"}
        # Never send the API-token Authorization header for user.checkAuthentication:
        # that method authenticates with the token in the params, and sending the
        # header alongside a session-based call would mix auth schemes.
        send_bearer = bool(getattr(self, "bearer", True)) and method != "user.checkAuthentication"
        if auth and send_bearer and self.api_token:
            headers["Authorization"] = "Bearer " + self.api_token
        elif auth and self._session_token:
            payload["auth"] = self._session_token
        request = urllib.request.Request(self.url, data=json.dumps(payload).encode("utf-8"), headers=headers)
        context = ssl._create_unverified_context() if self.url.lower().startswith("https") and not self.verify_ssl else None
        try:
            with urllib.request.urlopen(request, timeout=self.timeout, context=context) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                body = json.loads(exc.read().decode("utf-8"))
            except Exception as parse_error:
                raise ZabbixAPIError("HTTP %s from Zabbix API" % exc.code) from parse_error
        except urllib.error.HTTPError:
            raise
        except socket.timeout as exc:
            raise ZabbixAPIError("Request to Zabbix timed out after %s seconds." % self.timeout) from exc
        except urllib.error.URLError as exc:
            if isinstance(getattr(exc, "reason", None), socket.timeout):
                raise ZabbixAPIError("Request to Zabbix timed out after %s seconds." % self.timeout) from exc
            raise ZabbixAPIError("Cannot reach Zabbix API: %s" % getattr(exc, "reason", exc)) from exc
        except (ConnectionError, ssl.SSLError, OSError) as exc:
            raise ZabbixAPIError("Network error talking to Zabbix API: %s" % exc) from exc
        except (ValueError, json.JSONDecodeError) as exc:
            raise ZabbixAPIError("Invalid response from Zabbix API: %s" % exc) from exc
        except Exception as exc:
            raise ZabbixAPIError("Unexpected error talking to Zabbix: %s" % exc) from exc
        if "error" in body:
            error = body["error"]
            # Propagate the full API error so the UI sees the real Zabbix reason.
            data = (error.get("data") or "").strip()
            message = (error.get("message") or "").strip()
            detail = "; ".join(x for x in (message, data) if x) or "unknown error"
            raise ZabbixAPIError("Zabbix API error %s: %s" % (error.get("code"), detail))
        return body.get("result")

    @property
    def _session_token(self):
        return getattr(self, "session_token", "")

    def login(self):
        if self.api_token:
            self._request("apiinfo.version", {}, auth=False)
        else:
            if not self.user or not self.password:
                raise ZabbixAPIError("Provide an API token or username and password")
            params = {"username": self.user, "password": self.password}
            try:
                self.session_token = self._request("user.login", params, auth=False)
            except ZabbixAPIError:
                params["user"] = params.pop("username")
                self.session_token = self._request("user.login", params, auth=False)
            if not self.session_token:
                raise ZabbixAPIError("Zabbix login returned no session token")
        self.authenticated = True
        return self.api_token or self.session_token

    def resolve_token_owner(self):
        """Resolve the actual owner of the API token via the official
        user.checkAuthentication method (params {"token": <token>}).

        The token is only sent to Zabbix (Authorization header); it is never
        logged or included in any error message. Returns the owner username,
        preferring the modern "username" field with a fallback to "alias".
        """
        if not self.api_token:
            raise ZabbixAPIError("No API token available")
        # Zabbix 7.0 removed the optional "extend" parameter from
        # user.checkAuthentication; sending it triggers -32602 "unexpected parameter".
        # The token alone is valid on 6.0 and 7.0 alike, so send only the token.
        params = {"token": self.api_token}
        result = self._request("user.checkAuthentication", params, auth=False)
        if not isinstance(result, dict):
            raise ZabbixAPIError("Unexpected response from user.checkAuthentication")
        owner = str(result.get("username") or result.get("alias") or "").strip()
        if not owner:
            raise ZabbixAPIError("user.checkAuthentication returned no username")
        return owner

    def call(self, method, params=None, auth=True):
        if auth and not self.authenticated:
            raise ZabbixAPIError("Not authenticated")
        return self._request(method, params, auth)

    def metadata(self):
        groups = self.call("hostgroup.get", {"output": ["groupid", "name"], "sortfield": "name"}) or []
        templates = self.call("template.get", {"output": ["templateid", "name"], "sortfield": "name"}) or []


        version = self._api_version()
        if version is not None and version >= (7, 0):
            proxy_params = {"output": ["proxyid", "name", "proxy_groupid",
                                       "operating_mode", "lastaccess", "version"],
                            "sortfield": "name"}
        else:
            proxy_params = {"output": ["proxyid", "host"], "sortfield": "host"}
        try:
            raw_proxies = self.call("proxy.get", proxy_params) or []
        except ZabbixAPIError:
            raw_proxies = []
        proxies = [{"proxyid": x["proxyid"],
                    "name": x.get("name") or x.get("host") or x["proxyid"],
                    "proxy_groupid": x.get("proxy_groupid")}
                   for x in raw_proxies if x.get("proxyid")]
        try:
            proxy_groups = self.call("proxygroup.get", {"output": ["proxy_groupid", "name"], "sortfield": "name"}) or []
        except ZabbixAPIError:
            proxy_groups = []
        return {"groups": groups, "templates": templates, "proxies": proxies, "proxy_groups": proxy_groups}

    def _api_version(self):
        """Cached (major, minor) Zabbix version, or None when undetectable."""
        if self._version is None:
            try:
                v = self.call("apiinfo.version", {}, auth=False)
                if v:
                    self._version = tuple(int(x) for x in str(v).split(".")[:2])
            except ZabbixAPIError:
                self._version = None
        return self._version

    @staticmethod
    def _proxy_param_error(exc):
        """True when the API rejected a proxy parameter explicitly."""
        text = str(exc).lower()
        return "unexpected parameter" in text and "proxy" in text

    @staticmethod
    def _value_must_be_zero_error(exc):
        """True when the API complains that a (proxy) value must be 0."""
        text = str(exc).lower()
        return "must be 0" in text or "value must be zero" in text

    @staticmethod
    def sanitize_proxy_id(value):
        """Normalise a proxy/proxy-group ID.

        None, empty, whitespace-only, "0", "0.0", "none"/"null" (any case) and
        any non-numeric value all become None so the backend never sends a
        stray zero or malformed ID to the Zabbix API.
        """
        if value is None:
            return None
        if isinstance(value, bool):
            return None
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                return None
            value = ("%f" % value).rstrip("0").rstrip(".")
        text = str(value).strip()
        if not text:
            return None
        if text.lower() in ("0", "0.0", "none", "null", "-"):
            return None
        try:
            as_int = int(float(text))
        except (TypeError, ValueError):
            return None
        if as_int <= 0:
            return None
        return str(as_int)

    def create_host(self, payload):
        """Create a host using the proxy field supported by the Zabbix version.

        Zabbix >= 7 uses "proxyid" (and "proxy_groupid" for proxy groups);
        "proxy_hostid" was removed there. Zabbix < 7 only knows "proxy_hostid".
        The payload may carry any of proxyid / proxy_groupid / proxy_hostid;
        every value is sanitised (0/0.0/empty/none/non-numeric -> absent) and
        exactly one proxy field is ever sent. In Zabbix 7.0 "monitored_by"
        controls the mode: 2 = monitored by a proxy group (then "proxy_groupid"
        is sent), 1 = monitored by a normal proxy (then "proxyid" is sent).

        STRICT PROXY ASSIGNMENT: when a proxy/proxy-group is requested, the
        request is NEVER silently retried without the proxy fields. If Zabbix
        rejects the proxy assignment, the last underlying ZabbixAPIError is
        re-raised (with the method and payload keys for diagnosis; auth
        material is never included). Only requests without any requested
        proxy reach host.create without proxy fields.
        """
        payload = dict(payload)
        # A client-supplied monitored_by is ignored: we derive it from which
        # proxy field is present, so it must never conflict in the payload.
        payload.pop("monitored_by", None)
        pgid = self.sanitize_proxy_id(payload.pop("proxy_groupid", None))
        pid = self.sanitize_proxy_id(payload.pop("proxyid", None))
        phid = self.sanitize_proxy_id(payload.pop("proxy_hostid", None))
        version = self._api_version()
        is_legacy = version is not None and version < (7, 0)

        variants = []
        if is_legacy:
            if phid or pid:
                variants.append({"proxy_hostid": phid or pid})
        else:
            if pgid:
                variants.append({"monitored_by": 2, "proxy_groupid": pgid})
            elif pid or phid:
                variants.append({"monitored_by": 1, "proxyid": pid or phid})

        proxy_requested = bool(variants)
        method = "host.create"
        last_error = None
        for extra in variants:
            try:
                result = self.call(method, {**payload, **extra})
                return (result or {}).get("hostids", [None])[0]
            except ZabbixAPIError as exc:
                last_error = exc
                # Only a proxy-specific parameter rejection is retried with the
                # alternate legacy/new field spelling (same assignment intent);
                # any other error surfaces immediately.
                if self._proxy_param_error(exc) or self._value_must_be_zero_error(exc):
                    continue
                raise
        if proxy_requested:
            # STRICT MODE: the proxy assignment was requested and every allowed
            # spelling was rejected. Do NOT create the host unassigned; raise
            # the last underlying error (no auth material, only method + keys).
            payload_keys = sorted(k for k in payload.keys() if k not in
                                  ("password", "token", "session_token", "auth"))
            raise ZabbixAPIError(
                "Proxy assignment was requested but rejected by Zabbix; host was NOT created. "
                "method=%s payload_keys=%s underlying error: %s"
                % (method, payload_keys, last_error)
            ) from last_error
        # No proxy requested: a single attempt without any proxy field.
        result = self.call(method, payload)
        return (result or {}).get("hostids", [None])[0]

    def template_macros(self, templateids):
        rows = self.call("usermacro.get", {"output": ["hostmacroid", "macro", "value", "description"], "hostids": templateids}) or []
        return [{key: macro.get(key, "") for key in ("macro", "value", "description")} for macro in rows]

    def import_host(self, payload):
        """Create a host, then create its host-scoped value maps explicitly.

        Zabbix host.create does not create valuemaps. Keep them out of that
        request and report map failures with the already-created host ID.
        """
        host_payload = dict(payload)
        valuemaps = host_payload.pop("valuemaps", None) or []
        hostid = self.create_host(host_payload)
        if not hostid:
            raise ZabbixAPIError("host.create returned no host ID; valuemaps were not created")

        for vm in valuemaps:
            if not isinstance(vm, dict) or not vm.get("name"):
                raise ZabbixAPIError("Host %s was created, but value map payload is missing a name" % hostid)
            mappings = vm.get("mappings")
            if not isinstance(mappings, list) or not mappings:
                raise ZabbixAPIError(
                    'Host %s was created, but value map "%s" has no mappings' % (hostid, vm["name"])
                )
            params = {
                "hostid": str(hostid),
                "name": str(vm["name"]),
                "mappings": [],
            }
            for mapping in mappings:
                if not isinstance(mapping, dict):
                    raise ZabbixAPIError('Host %s was created, but value map "%s" has an invalid mapping' % (hostid, vm["name"]))
                mapping_type = int(mapping.get("type", 0))
                value = str(mapping.get("value", ""))
                newvalue = str(mapping.get("newvalue", ""))
                if not newvalue or (mapping_type != 5 and not value):
                    raise ZabbixAPIError('Host %s was created, but value map "%s" has an incomplete mapping' % (hostid, vm["name"]))
                params["mappings"].append({"type": mapping_type, "value": value, "newvalue": newvalue})
            try:
                self.call("valuemap.create", params)
            except Exception as exc:
                # Keep the complete API exception text (including Zabbix's returned reason) for the UI/log.
                raise ZabbixAPIError(
                    'Host %s was created, but value map "%s" failed: %s'
                    % (hostid, vm["name"], str(exc))
                ) from exc
        return hostid


    def _tcp_templates(self):
        rows = self.call("template.get", {"output": ["templateid", "name"],
                                          "filter": {"name": list(TCP_TEMPLATE_NAMES)}}) or []
        allowed = set(TCP_TEMPLATE_NAMES)
        return {row["name"]: str(row["templateid"]) for row in rows
                if row.get("name") in allowed and row.get("templateid")}

    def tcp_hosts(self):
        templates = self._tcp_templates()
        found = {}
        for name, templateid in templates.items():
            rows = self.call("host.get", {"output": ["hostid", "host", "name", "status"],
                                           "templateids": [templateid], "selectInterfaces": ["ip", "dns", "type", "main", "useip", "port"],
                                           "selectParentTemplates": ["templateid", "name"], "sortfield": "name"}) or []
            for host in rows:
                item = found.setdefault(str(host["hostid"]), dict(host))
                item.setdefault("tcp_templates", [])
                if name not in item["tcp_templates"]: item["tcp_templates"].append(name)
        return sorted(found.values(), key=lambda h: (h.get("name") or h.get("host") or "").lower())

    def tcp_host_details(self, hostid):
        """Return host metadata plus host-level and inherited TCP macro values."""
        if not str(hostid).isdigit():
            raise ZabbixAPIError("A valid host ID is required")
        templates = self._tcp_templates()
        rows = self.call("host.get", {"output": ["hostid", "host", "name", "status"],
                          "hostids": [str(hostid)], "selectInterfaces": ["ip", "dns", "type", "main", "useip", "port"],
                          "selectParentTemplates": ["templateid", "name"]}) or []
        if not rows:
            raise ZabbixAPIError("Host %s was not found" % hostid)
        host = rows[0]
        parent_rows = host.get("parentTemplates", []) or []
        linked = {x.get("name") for x in parent_rows}
        linked_ids = [str(x.get("templateid")) for x in parent_rows if x.get("templateid")]
        tcp_ids = {tid for name, tid in templates.items() if name in linked}
        # Some Zabbix versions omit parent template data; verify linkage by IDs.
        for name, tid in templates.items():
            if name not in linked:
                related = self.call("host.get", {"output": ["hostid"], "hostids": [str(hostid)], "templateids": [tid]}) or []
                if related:
                    linked.add(name)
                    tcp_ids.add(tid)
        host_macros = self.call("usermacro.get", {"output": ["hostmacroid", "macro", "value", "description"],
                                                    "hostids": [str(hostid)]}) or []
        # Query linked templates explicitly to expose values inherited when the host
        # does not define an override. Host-level values always win.
        template_macros = self.call("usermacro.get", {"output": ["hostmacroid", "macro", "value", "description"],
                                                        "hostids": linked_ids}) if linked_ids else []
        host_values = {m.get("macro"): {"value": m.get("value", ""), "hostmacroid": m.get("hostmacroid")}
                       for m in host_macros if m.get("macro") in TCP_MACROS}
        effective = {}
        for m in (template_macros or []):
            if m.get("macro") in TCP_MACROS:
                effective.setdefault(m["macro"], {"value": m.get("value", ""), "source": "template"})
        for macro, item in host_values.items():
            effective[macro] = {"value": item["value"], "source": "host", "hostmacroid": item.get("hostmacroid")}
        host["tcp_templates"] = [name for name in TCP_TEMPLATE_NAMES if name in linked]
        host["host_macros"] = host_values
        host["macros"] = effective
        return host

    def tcp_update_macros(self, hostid, values):
        """Create or update host-scoped TCP macros and report each action.

        Empty strings are intentional values (for clearing a macro), while
        None and structured values are rejected instead of being stringified.
        """
        if not isinstance(hostid, (str, int)) or not str(hostid).isdigit():
            raise ZabbixAPIError("A valid host ID is required")
        if not isinstance(values, dict) or not values:
            raise ZabbixAPIError("No macro values were supplied")
        if any(not isinstance(name, str) for name in values):
            raise ZabbixAPIError("Macro names must be strings")
        allowed = TCP_MACROS - {"{$PORT_RES_TRSH}"}
        invalid = set(values) - allowed
        if invalid:
            raise ZabbixAPIError("Macro is not allowed for TCP settings: %s" % ", ".join(sorted(invalid)))
        for macro, value in values.items():
            if value is None or isinstance(value, (dict, list, tuple, set)):
                raise ZabbixAPIError("Macro %s must have a scalar value (empty string is allowed)" % macro)

        current = self.call("usermacro.get", {
            "output": ["hostmacroid", "macro", "value", "type", "description"],
            "hostids": [str(hostid)],
        }) or []
        by_name = {m.get("macro"): m for m in current
                   if isinstance(m, dict) and m.get("macro") in TCP_MACROS}
        results = []
        for macro, value in values.items():
            value = str(value)  # preserve "" for explicit clearing
            old = by_name.get(macro)
            if value == "":
                # Empty string means "clear the macro": delete it when it exists
                # on the host, and skip creating it entirely when it does not.
                if old:
                    macroid = old.get("hostmacroid")
                    if not macroid:
                        raise ZabbixAPIError("Existing macro %s has no host macro ID; cannot delete it" % macro)
                    self.call("usermacro.delete", [macroid])
                    results.append({"macro": macro, "action": "deleted"})
                else:
                    results.append({"macro": macro, "action": "skipped"})
                continue
            if old:
                macroid = old.get("hostmacroid")
                if not macroid:
                    raise ZabbixAPIError("Existing macro %s has no host macro ID; cannot update it" % macro)
                self.call("usermacro.update", {"hostmacroid": macroid, "value": value})
                results.append({"macro": macro, "action": "updated"})
            else:
                self.call("usermacro.create", {"hostid": str(hostid), "macro": macro, "value": value})
                results.append({"macro": macro, "action": "created"})
        return results
