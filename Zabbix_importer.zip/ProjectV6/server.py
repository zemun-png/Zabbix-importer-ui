"""Standalone HTTP server for the Zabbix Importer UI and JSON-RPC bridge."""
from __future__ import annotations
import json
import mimetypes
import os
import secrets
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import re
import config
from audit import log_app_login_event, log_host_event, log_tcp_macro_event
from report_export import build_report_workbook
from zabbix_api import ZabbixAPI, ZabbixAPIError

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.realpath(os.path.join(ROOT_DIR, config.STATIC_DIR))
_SESSIONS = {}
_SESSIONS_LOCK = threading.Lock()
DEFAULT_TAGS = ("Z-Admin", "Z-HStatus", "Z-Owner", "Z-Role", "Z-Type", "Z-Zone", "Z-Ticket")
FIXED_STATUS_TAG = {"tag": "Z-HStatus", "value": "InProgress"}

# Strict IPv4 validation (no partial addresses such as "10.10.10").
IPV4_RE = re.compile(r"^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$")

def validate_host_interface_ips(payload):
    """Reject host payloads whose interface IPs are not strict IPv4 addresses.
    DNS names and empty values are allowed; partial IPs like "10.10.10" are not."""
    interfaces = payload.get("interfaces") if isinstance(payload.get("interfaces"), list) else []
    for item in interfaces:
        if not isinstance(item, dict):
            continue
        ip = str(item.get("ip", "") or "").strip()
        if not ip:
            continue
        if not IPV4_RE.match(ip):
            raise ValueError(
                "Invalid interface IP '%s' for host '%s': a full IPv4 address "
                "(e.g. 10.10.10.10) is required." % (ip, payload.get("host") or "(unnamed)")
            )
    return True


def normalize_tags(tags):
    """Keep only user-provided tags with a non-empty name; never re-add tags the
    user deleted (no empty-valued default tags). Z-HStatus stays locked to
    InProgress and is always present exactly once."""
    result, seen = [], set()
    for item in tags if isinstance(tags, list) else []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("tag", "")).strip()
        if not name:            # skip empty/deleted tag rows entirely
            continue
        if name == "Z-HStatus":
            if "Z-HStatus" not in seen:
                seen.add("Z-HStatus")
                result.append(dict(FIXED_STATUS_TAG))
            continue
        if name in seen:
            continue
        seen.add(name)
        result.append({"tag": name, "value": str(item.get("value", "")).strip()})
    if "Z-HStatus" not in seen:
        result.append(dict(FIXED_STATUS_TAG))
    return result


def get_api(handler=None, body=None):
    session_id = (handler.headers.get("X-Importer-Session", "") if handler else "") or str((body or {}).get("session_id", ""))
    with _SESSIONS_LOCK:
        record = _SESSIONS.get(session_id)
    if not record:
        raise ZabbixAPIError("Not connected. Authenticate first.")
    client = record.get("client")
    if client is not None:
        return client, record["username"]
    client = ZabbixAPI(url=record["url"], api_token=record.get("api_token", ""), user=record["username"])
    if record.get("session_token"):
        client.session_token = record["session_token"]
        client.authenticated = True
    if record.get("api_token"):
        client.api_token = record["api_token"]
        client.authenticated = True
    return client, record["username"]


TCP_PAIR_KEYS = (
    ("{$DST_IP}", "{$DST_PORT}"),
    ("{$DST_IP_EXTERNAL}", "{$DST_PORT_EXTERNAL}"),
    ("{$DST_IP_INTERNAL}", "{$DST_PORT_INTERNAL}"),
)


def _macro_text(value):
    """Flatten a macro value (str or {"value": ...}) into normalized text."""
    if isinstance(value, dict):
        value = value.get("value", "")
    return str(value if value is not None else "").strip()


def tcp_pairs_from_macros(macros):
    """Expand the parallel {$DST_IP*} / {$DST_PORT*} arrays into {ip, port} pairs."""
    macros = macros if isinstance(macros, dict) else {}
    pairs = set()
    for ip_macro, port_macro in TCP_PAIR_KEYS:
        ips = [x.strip() for x in _macro_text(macros.get(ip_macro)).split(",")]
        ports = [x.strip() for x in _macro_text(macros.get(port_macro)).split(",")]
        count = max(len(ips), len(ports))
        for index in range(count):
            ip = ips[index] if index < len(ips) else ""
            port = ports[index] if index < len(ports) else ""
            if ip or port:
                pairs.add((ip, port))
    return pairs


def tcp_macro_diff(before, after):
    """Return added/removed/modified TCP destination pairs between two macro maps."""
    old_pairs, new_pairs = tcp_pairs_from_macros(before), tcp_pairs_from_macros(after)
    old_ips = {ip for ip, _ in old_pairs if ip}
    new_ips = {ip for ip, _ in new_pairs if ip}
    diff = {"added": [], "removed": [], "modified": []}
    for ip, port in sorted(new_pairs):
        if (ip, port) in old_pairs:
            continue
        if ip and ip not in old_ips:
            diff["added"].append({"ip": ip, "port": port})
        elif ip and ip in old_ips:
            diff["modified"].append({"ip": ip, "port": port})
        else:
            diff["added"].append({"ip": ip, "port": port})
    for ip, port in sorted(old_pairs):
        if (ip, port) in new_pairs:
            continue
        if ip and ip in new_ips:
            # Same IP still present but this port went away: that is a modification.
            if not any(item["ip"] == ip for item in diff["modified"]):
                diff["modified"].append({"ip": ip, "port": port})
        else:
            diff["removed"].append({"ip": ip, "port": port})
    for key in ("added", "removed", "modified"):
        diff[key].sort(key=lambda item: (item["ip"], item["port"]))
    return diff



def sanitize_host_proxy_fields(payload):
    """Sanitise proxy fields on an incoming host payload (in place).

    Uses ZabbixAPI.sanitize_proxy_id so empty/0/0.0/null/non-numeric values
    are dropped. Exactly one of proxyid / proxy_groupid survives: proxyid wins
    when valid, otherwise proxy_groupid. proxy_hostid is left in place for the
    legacy (< 7.0) mapping that create_host performs.
    Returns the (mutated) payload."""
    pid = ZabbixAPI.sanitize_proxy_id(payload.get("proxyid"))
    pgid = ZabbixAPI.sanitize_proxy_id(payload.get("proxy_groupid"))
    payload.pop("proxyid", None)
    payload.pop("proxy_groupid", None)
    payload.pop("monitored_by", None)     # derived in create_host, never sent raw
    if pid:
        payload["proxyid"] = pid          # valid proxyid -> drop proxy_groupid
    elif pgid:
        payload["proxy_groupid"] = pgid   # valid group -> proxyid already removed
    # proxy_hostid kept for Zabbix < 7 mapping inside create_host.
    return payload

def build_export_report(api, body=None):
    """Collect TCP hosts (client-supplied or fetched live) and build the styled
    merged-cell Excel report bytes via report_export.build_report_workbook."""
    body = body if isinstance(body, dict) else {}
    hosts = body.get("hosts")
    if not isinstance(hosts, list):
        hosts = api.tcp_hosts() or []
    if not isinstance(hosts, list):
        raise ValueError("hosts must be a list")
    enriched = []
    for host in hosts:
        if not isinstance(host, dict):
            continue
        item = dict(host)
        if not any(k in item for k in ("host_ip", "interface_ip", "ip", "host_ip_address")):
            iface_ip = next(
                (str(i.get("ip") or "").strip() for i in item.get("interfaces", []) or []
                 if isinstance(i, dict) and str(i.get("ip") or "").strip()), "")
            if iface_ip:
                item["host_ip"] = iface_ip
        if not isinstance(item.get("macros"), dict):
            try:
                details = api.tcp_host_details(item.get("hostid") or item.get("host"))
                item["macros"] = (details or {}).get("macros") or {}
            except Exception:
                item["macros"] = {}
        enriched.append(item)
    return build_report_workbook(enriched)


class ImporterHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ZabbixImporter/1.0"

    def log_message(self, fmt, *args):
        if getattr(config, "WEB_DEBUG", False):
            super().log_message(fmt, *args)


    def _client_ip(self):
        """Best-effort client address: X-Forwarded-For first hop, X-Real-IP,
        then the direct socket address. Header values are never logged raw."""
        forwarded = (self.headers.get("X-Forwarded-For") or "").strip()
        if forwarded:
            first = forwarded.split(",")[0].strip()
            if first:
                return first
        real_ip = (self.headers.get("X-Real-IP") or "").strip()
        if real_ip:
            return real_ip
        return self.client_address[0] if self.client_address else "(unknown)"

    def _send(self, status, body, content_type="application/json; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj, ensure_ascii=False))

    def _error(self, message, status=500):
        self._json({"error": str(message)}, status)

    def _read_body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > 10 * 1024 * 1024:
                raise ValueError("Request body is too large")
            raw = self.rfile.read(length)
            obj = json.loads(raw.decode("utf-8")) if raw else {}
            if not isinstance(obj, dict):
                raise ValueError("JSON body must be an object")
            return obj
        except Exception as exc:
            raise ValueError("Invalid JSON request: %s" % exc) from exc

    def _serve_index(self):
        path = os.path.join(ROOT_DIR, "index.html")
        if not os.path.isfile(path):
            return self._send(404, "index.html not found", "text/plain; charset=utf-8")
        with open(path, "rb") as stream:
            self._send(200, stream.read(), "text/html; charset=utf-8")

    def _serve_static(self, relative_path):
        relative_path = urllib.parse.unquote(relative_path).replace("\\", "/").lstrip("/")
        path = os.path.realpath(os.path.join(STATIC_DIR, relative_path))
        if not path.startswith(STATIC_DIR + os.sep) or not os.path.isfile(path):
            return self._send(404, "Not found", "text/plain; charset=utf-8")
        content_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if content_type.startswith(("text/", "application/javascript", "application/json")):
            content_type += "; charset=utf-8"
        with open(path, "rb") as stream:
            self._send(200, stream.read(), content_type)

    def do_GET(self):
        route = urllib.parse.urlparse(self.path).path.rstrip("/") or "/"
        if route in ("/", "/index.html"):
            return self._serve_index()
        if route.startswith("/static/"):
            return self._serve_static(route[len("/static/"):])
        if route in ("/api/status", "/api/metadata"):
            try:
                api, _ = get_api(self)
                if route.endswith("metadata"):
                    self._json(api.metadata())
                else:
                    self._json({"ok": True})
            except Exception as exc:
                self._json({"ok": False, "error": str(exc), "groups": [], "templates": [], "proxies": []}, 401)
            return
        return self._send(404, "Not found", "text/plain; charset=utf-8")

    def do_POST(self):
        route = urllib.parse.urlparse(self.path).path.rstrip("/")
        try:
            body = self._read_body()
        except ValueError as exc:
            return self._error(exc, 400)
        if route == "/api/login":
            return self._handle_login(body)
        if route == "/api/import":
            return self._handle_import(body)
        if route == "/api/tcp_hosts":
            try:
                api, _ = get_api(self, body)
                return self._json({"hosts": api.tcp_hosts()})
            except Exception as exc:
                return self._error(exc, 401)
        if route == "/api/tcp_host_details":
            try:
                api, _ = get_api(self, body)
                hostid = body.get("hostid")
                return self._json({"host": api.tcp_host_details(hostid)})
            except Exception as exc:
                return self._error(exc, 400)
        if route == "/api/tcp_update_macros":
            try:
                api, username = get_api(self, body)
                hostid = body.get("hostid")
                before = {}
                try:
                    details = api.tcp_host_details(hostid)
                    before = (details or {}).get("macros") or {}
                except Exception:
                    before = {}
                result = api.tcp_update_macros(hostid, body.get("macros"))
                after = {}
                try:
                    details = api.tcp_host_details(hostid)
                    after = (details or {}).get("macros") or {}
                except Exception:
                    after = body.get("macros") if isinstance(body.get("macros"), dict) else {}
                diff = tcp_macro_diff(before, after)
                hostname = str((before and "") or body.get("hostname") or "")
                log_tcp_macro_event(username, hostid, hostname, diff, client_ip=self._client_ip())
                # Keep "results" for backward compatibility and add the audited diff.
                return self._json({"results": result, "diff": diff})
            except Exception as exc:
                try:
                    log_tcp_macro_event(locals().get("username") or "(unknown)",
                                        body.get("hostid"), "", None, "failed", str(exc),
                                        client_ip=self._client_ip())
                except Exception:
                    pass
                return self._error(exc, 400)
        if route == "/api/export-report":
            try:
                api, _ = get_api(self, body)
                data = build_export_report(api, body)
            except ZabbixAPIError as exc:
                return self._error(exc, 401)
            except Exception as exc:
                return self._error(exc, 400)
            filename = time.strftime("zabbix_tcp_report_%Y%m%d_%H%M%S.xlsx")
            self.send_response(200)
            self.send_header("Content-Type",
                             "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass
            return
        if route == "/api/template-macros":
            try:
                api, _ = get_api(self, body)
                ids = body.get("templateids") or []
                if not isinstance(ids, list):
                    return self._error("templateids must be a list", 400)
                return self._json({"macros": api.template_macros(ids)})
            except Exception as exc:
                return self._error(exc, 401)
        return self._send(404, "Not found", "text/plain; charset=utf-8")

    def _handle_login(self, body):
        url = (body.get("url") or config.ZABBIX_URL).strip()
        username = (body.get("username") or "").strip()
        password = body.get("password") or ""
        api_token = (body.get("api_token") or body.get("token") or "").strip()
        if not url or (not api_token and (not username or not password)):
            return self._error("Enter a Zabbix URL and API token or username/password.", 400)
        auth_method = "api_token" if api_token else "username_password"
        client_ip = self._client_ip()
        try:
            client = ZabbixAPI(url=url, api_token=api_token, user=username, password=password)
            client.login()
            if api_token:
                display_user = client.resolve_token_owner()
            else:
                display_user = username
        except Exception as exc:
            # Safe audit entry: no password, token, or header values are logged.
            try:
                log_app_login_event(username or "(API token user)", client_ip, auth_method,
                                    "failed", str(exc), url)
            except Exception:
                pass
            return self._json({"ok": False, "error": str(exc)}, 401)
        session_id = secrets.token_urlsafe(32)
        with _SESSIONS_LOCK:
            _SESSIONS[session_id] = {
                "client": client,
                "url": url,
                "api_token": api_token,
                "session_token": "" if api_token else getattr(client, "session_token", ""),
                "username": display_user,
                "created_at": time.time(),
            }
        try:
            log_app_login_event(display_user, client_ip, auth_method, "success", "", url)
        except Exception:
            pass
        self._json({"ok": True, "session_id": session_id, "username": display_user})

    def _handle_import(self, body):
        try:
            api, username = get_api(self, body)
        except Exception as exc:
            return self._error(exc, 401)
        hosts = body.get("hosts") or []
        if not isinstance(hosts, list):
            return self._error("hosts must be a list", 400)
        mode = str(body.get("mode") or ("bulk" if body.get("bulk") else "single"))
        results = []
        for payload in hosts:
            if not isinstance(payload, dict):
                results.append({"status": "ERROR", "host": "(invalid)", "error": "Host payload must be an object"})
                continue
            name = str(payload.get("host") or "(unnamed)")
            ip = next((str(item.get("ip", "")) for item in payload.get("interfaces", []) if isinstance(item, dict) and item.get("ip")), "")
            payload["tags"] = normalize_tags(payload.get("tags"))
            try:
                validate_host_interface_ips(payload)
                sanitize_host_proxy_fields(payload)
                host_id = api.import_host(payload)
                log_host_event(username, name, ip, mode, "success", hostid=host_id)
                results.append({"status": "OK", "host": name, "hostid": host_id})
            except Exception as exc:
                log_host_event(username, name, ip, mode, "failed", str(exc))
                results.append({"status": "ERROR", "host": name, "error": str(exc)})
        return self._json({"results": results})


class ImporterServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    server = ImporterServer((config.WEB_HOST, config.WEB_PORT), ImporterHandler)
    print("Zabbix Importer UI running at http://%s:%s/" % (config.WEB_HOST, config.WEB_PORT))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
